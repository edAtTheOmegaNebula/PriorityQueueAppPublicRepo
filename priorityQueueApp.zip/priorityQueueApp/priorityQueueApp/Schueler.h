//  Schueler.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class models a pupil.
//  Reason: Objects of this class are evaluated in order to determine the next pupil to be processed by priority.
//  Author: Edhem Bajrić
//  Date: 15.05.2020

#ifndef Schueler_h
#define Schueler_h

#include <stdio.h>
#include <iostream>
#include <stdexcept>
#include <regex>
#include <sstream>

class Schueler
{
    friend class SchuelerTest;
public:
    Schueler(int id, std::string name, double cgpa) throw(std::invalid_argument);
    Schueler() throw(std::invalid_argument);
    int getId() throw(std::invalid_argument);
    void setId(int newId) throw(std::invalid_argument);
    std::string getName() throw(std::invalid_argument);
    void setName(std::string newName) throw(std::invalid_argument);
    double getCgpa() throw(std::invalid_argument);
    void setCgpa(double newCgpa) throw(std::invalid_argument);
    std::string convertToString() throw(std::invalid_argument);
    bool equalsTo(Schueler newSchueler);
private:
    int m_id;
    std::string m_name;
    double m_cgpa;
    int m_idMax = 100000;
    int m_idMin = 0;
    double m_cgpaMax = 4.00;
    double m_cgpaMin = 0;
};

#endif /* Schueler_h */
