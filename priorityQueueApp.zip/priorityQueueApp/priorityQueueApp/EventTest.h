//  EventTest.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 17.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class implements tests for the class Event.
//  Reason: Test automation.
//  Author: Edhem Bajrić
//  Date: 17.05.2020

#ifndef EventTest_h
#define EventTest_h

#include <stdio.h>
#include <stdexcept>
#include "Event.h"
#include "Schueler.h"

class EventTest
{
public:
    void runAllTests() throw(std::runtime_error);
private:
    void testConstructorForQuitEventsAndCorrectlyUsedEventTypeSetter() throw(std::runtime_error);
    void testConstructorForPrintEventsAndCorrectlyUsedEventTypeSetter() throw(std::runtime_error);
    void testConstructorForServedEventsAndCorrectlyUsedEventTypeSetter() throw(std::runtime_error);
    void testExplicitConstructorForEnterEventAndCorrectlyUsedEventTypeSchuelerSetters() throw(std::runtime_error);
    void testSetWrongEventType() throw(std::runtime_error);
    void testGetEventType() throw(std::runtime_error);
    void testGetWrongEventType() throw(std::runtime_error);
    void testGetSchueler() throw(std::runtime_error);
};

#endif /* EventTest_h */
