//  Priorities.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class processes all events and to display a list of pupils, sorted by priority.
//  Reason: Objects of this class evaluate the priority of pupils to manage.
//  Author: Edhem Bajrić
//  Date: 15.05.2020

#ifndef Priorities_h
#define Priorities_h

#include <stdio.h>
#include <iostream>
#include <list>
#include <stdexcept>
#include <sstream>
#include "Schueler.h"
#include "Event.h"
#include "EventTypes.h"

class Priorities
{
    friend class PrioritiesTest;
public:
    Priorities();
    std::list<Schueler> getSchuelers(std::list<std::string> events) throw(std::invalid_argument);
    void eraseSchuelerList();
private:
    std::list<Schueler> m_schuelerList;
    bool m_isListSortedByCgpa;
    bool m_isListSortedByNames;
    bool m_isListSortedByIdentifier;
    std::list<Schueler> getSchuelerList();
    void setSchuelerList(std::list<Schueler> newSchuelerList) throw(std::invalid_argument);
    Event parseEvent(std::string event) throw(std::invalid_argument);
    void printSchuelerList(std::list<Schueler> schuelerListToPrint);
    void sortByCgpa() throw(std::invalid_argument);
    void sortByNames() throw(std::invalid_argument);
    void sortByIdentifiers() throw(std::invalid_argument);
    void sortByPriorities() throw(std::invalid_argument);
    bool getIsListSortedByCgpa();
    void setIsListSortedByCgpa(bool newIsListSortedByCgpa);
    bool getIsListSortedByNames();
    void setIsListSortedByNames(bool newIsListSortedByNames);
    bool getIsListSortedByIdentifier();
    void setIsListSortedByIdentifier(bool newIsListSortedByIdentifier);
};

#endif /* Priorities_h */
