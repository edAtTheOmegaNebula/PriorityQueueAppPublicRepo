//  EventTypesTest.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 17.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class implements tests for the class EventTypes.
//  Reason: Test automation.
//  Author: Edhem Bajrić
//  Date: 17.05.2020

#ifndef EventTypesTest_h
#define EventTypesTest_h

#include <stdio.h>
#include <stdexcept>
#include "EventTypes.h"

class EventTypesTest
{
public:
    void runAllTests() throw(std::runtime_error);
private:
    void testStandardConstructorAndCorrectlyUsedEnterQuitServedPrintSetters() throw(std::runtime_error);
    void testSetWrongEnter() throw(std::runtime_error);
    void testSetWrongQuit() throw(std::runtime_error);
    void testSetWrongServed() throw(std::runtime_error);
    void testSetWrongPrint() throw(std::runtime_error);
    void testGetEnter() throw(std::runtime_error);
    void testGetWrongEnter() throw(std::runtime_error);
    void testGetQuit() throw(std::runtime_error);
    void testGetWrongQuit() throw(std::runtime_error);
    void testGetServed() throw(std::runtime_error);
    void testGetWrongServed() throw(std::runtime_error);
    void testGetPrint() throw(std::runtime_error);
    void testGetWrongPrint() throw(std::runtime_error);
};

#endif /* EventTypesTest_h */
