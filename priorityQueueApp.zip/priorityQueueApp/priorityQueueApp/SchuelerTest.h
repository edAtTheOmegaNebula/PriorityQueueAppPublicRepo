//  SchuelerTest.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 16.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class implements tests for the class Schueler.
//  Reason: Test automation.
//  Author: Edhem Bajrić
//  Date: 16.05.2020

#ifndef SchuelerTest_h
#define SchuelerTest_h

#include <stdio.h>
#include <stdexcept>
#include "Schueler.h"

class SchuelerTest
{
public:
    void runAllTests() throw(std::runtime_error);
private:
    void testStandardConstructorAndCorrectlyUsedIdNameCgpaSetters() throw(std::runtime_error);
    void testExplicitConstructorAndWronglySetId() throw(std::runtime_error);
    void testSetWrongName() throw(std::runtime_error);
    void testSetWrongCgpa() throw(std::runtime_error);
    void testGetId() throw(std::runtime_error);
    void testGetWrongId() throw(std::runtime_error);
    void testGetName() throw(std::runtime_error);
    void testGetWrongName() throw(std::runtime_error);
    void testGetCgpa() throw(std::runtime_error);
    void testGetWrongCgpa() throw(std::runtime_error);
    void testConvertToString() throw(std::runtime_error);
    void testEqualsToIdentity() throw(std::runtime_error);
    void testEqualsToDiversity() throw(std::runtime_error);
};

#endif /* SchuelerTest_h */
