//  PrioritiesTest.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 17.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class implements tests for the class Priorities.
//  Reason: Test automation. Since the getters and setters for the members m_isListSortedByCgpa, m_isListSortedByNames, m_isListSortedByIdentifier currently do not implement any business complex logic, the corresponding tests were left out.
//  Author: Edhem Bajrić
//  Date: 16.05.2020

#ifndef PrioritiesTest_h
#define PrioritiesTest_h

#include <stdio.h>
#include <stdexcept>
#include <sstream>
#include "Priorities.h"

class PrioritiesTest
{
public:
    void runAllTests() throw(std::runtime_error);
private:
    void testSetSchuelerList() throw(std::runtime_error);
    void testSetWrongSchuelerList() throw(std::runtime_error);
    void testGetSchuelerList() throw(std::runtime_error);
    void testEraseSchuelerList() throw(std::runtime_error);
    void testPrintSchuelerList() throw(std::runtime_error);
    void testParseQuitEvent() throw(std::runtime_error);
    void testParsePrintEvent() throw(std::runtime_error);
    void testParseServedEvent() throw(std::runtime_error);
    void testParseEnterEvent() throw(std::runtime_error);
    void testParseEmptyEvent() throw(std::runtime_error);
    void testParseWrongEvent() throw(std::runtime_error);
    void testSortEmptyListByCgpa() throw(std::runtime_error);
    void testSortAn1EntryListByCgpa() throw(std::runtime_error);
    void testSortByCgpa() throw(std::runtime_error);
    void testSortEmptyListByNames() throw(std::invalid_argument);
    void testSortAn1EntryListByNames() throw(std::invalid_argument);
    void testSortUnsortedListByNames() throw(std::invalid_argument);
    void testSortByNames() throw(std::invalid_argument);
    void testEmptyListSortByIdentifiers() throw(std::invalid_argument);
    void testSortAn1EntryListByIdentifiers() throw(std::invalid_argument);
    void testSortUnsortedListByIdentifiers() throw(std::invalid_argument);
    void testSortByIdentifiers() throw(std::invalid_argument);
    void testSortEmptyListByPriorities() throw(std::invalid_argument);
    void testSortAn1EntryListByPriorities() throw(std::invalid_argument);
    void testSortByPriorities() throw(std::invalid_argument);
    void testGetSchuelersWithEmptyEvent() throw(std::invalid_argument);
    void testGetSchuelersWithQuitEvent() throw(std::invalid_argument);
    void testGetSchuelersWithPrintEvent() throw(std::invalid_argument);
    void testGetSchuelersWithServedEventOnEmptyList() throw(std::invalid_argument);
    void testGetSchuelersWithServedEventOnFilledList() throw(std::invalid_argument);
    void testGetSchuelersWithEnterEventOnEmptyList() throw(std::invalid_argument);
    void testGetSchuelersWithEnterEventOnFilledList() throw(std::invalid_argument);
    std::list<Schueler> m_schuelerListForTest;
    bool areSchuelerListsEqual(std::list<Schueler> firstList, std::list<Schueler> secondList);
};

#endif /* PrioritiesTest_h */
