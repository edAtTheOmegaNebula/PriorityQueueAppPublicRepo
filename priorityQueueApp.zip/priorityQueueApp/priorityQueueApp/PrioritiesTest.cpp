//  PrioritiesTest.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 17.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include "PrioritiesTest.h"

//  Purpose: The following method just eases the comparison of two list of pupils. It is not part of the tests for the class Priorities.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
bool PrioritiesTest::areSchuelerListsEqual(std::list<Schueler> firstList, std::list<Schueler> secondList)
{
    if (firstList.empty() == true && secondList.empty() == true)
    {
        return true;
    }
    else if (firstList.size() != secondList.size())
    {
        return false;
    }
    else
    {
        for (int i = 0; i < firstList.size(); i++)
        {
            std::list<Schueler>::iterator ithSchuelerOfFirstList = firstList.begin();
            std::list<Schueler>::iterator ithSchuelerOfSecondList = secondList.begin();
            std::advance(ithSchuelerOfFirstList, i);
            std::advance(ithSchuelerOfSecondList, i);
            if ((*ithSchuelerOfFirstList).equalsTo(*ithSchuelerOfSecondList))
            {
                continue;
            }
            else
            {
                return false;
            }
        }
        return true;
    }
}

//  Purpose: The following test covers the standard constructor as well as the definition of list of pupils.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSetSchuelerList() throw(std::runtime_error)
{
    Priorities priorities;
    std::list<Schueler> newListOfSchuelerForTest;
    Schueler schuelerLinda(11, "Linda", 1.11);
    newListOfSchuelerForTest.push_back(schuelerLinda);
    try
    {
        priorities.setSchuelerList(newListOfSchuelerForTest);
        std::cout << "PrioritiesTest::testSetSchuelerList(): Test passed.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testSetSchuelerList(): Test failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as the trial defining an invalid list of pupils.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSetWrongSchuelerList() throw(std::runtime_error)
{
    Priorities priorities;
    std::list<Schueler> newListOfSchuelerForTest;
    try
    {
        priorities.setSchuelerList(newListOfSchuelerForTest);
        throw std::runtime_error("PrioritiesTest::testSetWrongSchuelerList(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testSetWrongSchuelerList(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a previously set list of pupils.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testGetSchuelerList() throw(std::runtime_error)
{
    Priorities priorities;
    std::list<Schueler> newListOfSchuelerForTest;
    Schueler expectedSchuelerLinda(11, "Linda", 1.11);
    newListOfSchuelerForTest.push_back(expectedSchuelerLinda);
    priorities.setSchuelerList(newListOfSchuelerForTest);
    try
    {
        Schueler actualSchuelerLinda = priorities.getSchuelerList().front();
        bool areIdsEqual = (actualSchuelerLinda.getId() == expectedSchuelerLinda.getId());
        bool areNamesEqual = (actualSchuelerLinda.getName() == expectedSchuelerLinda.getName());
        bool areCgpasEqual = (actualSchuelerLinda.getCgpa() == expectedSchuelerLinda.getCgpa());
        if (areIdsEqual == true && areNamesEqual == true && areCgpasEqual == true)
        {
            std::cout << "PrioritiesTest::testGetSchuelerList(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testGetSchuelerList(): Test failed. Inserted pupil data differs from extracted one.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testGetSchuelerList(): Test failed. Getting the list failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as erasing a dummy list of pupils.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testEraseSchuelerList() throw(std::runtime_error)
{
    Priorities priorities;
    std::list<Schueler> newListOfSchuelerForTest;
    Schueler expectedSchuelerLinda(11, "Linda", 1.11);
    newListOfSchuelerForTest.push_back(expectedSchuelerLinda);
    priorities.setSchuelerList(newListOfSchuelerForTest);
    try
    {
        priorities.eraseSchuelerList();
        if (priorities.getSchuelerList().empty() == true)
        {
            std::cout << "PrioritiesTest::testEraseSchuelerList(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testEraseSchuelerList(): Test failed. The list still contains data.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testEraseSchuelerList(): Test failed. Erasing the list failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as printing a dummy list of pupils. Since the result of printing is located at stdout, this test technically passes always, but its result has to be checket manally. The result must be:
//      Pupil: Name = Linda, ID = 11, CGPA = 1.11.
//      Pupil: Name = Joe, ID = 12, CGPA = 1.12.
//      Pupil: Name = Avril, ID = 13, CGPA = 1.22.
//      Pupil: Name = Dwight, ID = 14, CGPA = 1.14.
//      Pupil: Name = Oprah, ID = 15, CGPA = 1.15.
//      Pupil: Name = Antony, ID = 16, CGPA = 1.16.
//      Pupil: Name = Beth, ID = 17, CGPA = 1.17.
//      Pupil: Name = Louie, ID = 18, CGPA = 1.11.
//      Pupil: Name = Betty, ID = 19, CGPA = 1.19.
//      Pupil: Name = Lee, ID = 20, CGPA = 1.2.
//      Pupil: Name = Tracy, ID = 21, CGPA = 1.21.
//      Pupil: Name = Louie, ID = 22, CGPA = 1.22.
//      Pupil: Name = Beth, ID = 17, CGPA = 1.23.
//      Pupil: Name = Dwight, ID = 23, CGPA = 1.14.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testPrintSchuelerList() throw(std::runtime_error)
{
    Priorities priorities;
    Schueler schuelerLinda(11, "Linda", 1.11);
    Schueler schuelerJoe(12, "Joe", 1.12);
    Schueler schuelerAvril(13, "Avril", 1.22);
    Schueler schuelerDwight(14, "Dwight", 1.14);
    Schueler schuelerOprah(15, "Oprah", 1.15);
    Schueler schuelerAntony(16, "Antony", 1.16);
    Schueler schuelerBeth(17, "Beth", 1.17);
    Schueler schuelerLouie(18, "Louie", 1.11);
    Schueler schuelerBetty(19, "Betty", 1.19);
    Schueler schuelerLee(20, "Lee", 1.20);
    Schueler schuelerTracy(21, "Tracy", 1.21);
    Schueler schuelerGary(22, "Louie", 1.22);
    Schueler schuelerAnotherBeth(17, "Beth", 1.23);
    Schueler schuelerAnotherDwight(23, "Dwight", 1.14);
    std::list<Schueler> newListOfSchuelerForTest;
    newListOfSchuelerForTest.push_back(schuelerLinda);
    newListOfSchuelerForTest.push_back(schuelerJoe);
    newListOfSchuelerForTest.push_back(schuelerAvril);
    newListOfSchuelerForTest.push_back(schuelerDwight);
    newListOfSchuelerForTest.push_back(schuelerOprah);
    newListOfSchuelerForTest.push_back(schuelerAntony);
    newListOfSchuelerForTest.push_back(schuelerBeth);
    newListOfSchuelerForTest.push_back(schuelerLouie);
    newListOfSchuelerForTest.push_back(schuelerBetty);
    newListOfSchuelerForTest.push_back(schuelerLee);
    newListOfSchuelerForTest.push_back(schuelerTracy);
    newListOfSchuelerForTest.push_back(schuelerGary);
    newListOfSchuelerForTest.push_back(schuelerAnotherBeth);
    newListOfSchuelerForTest.push_back(schuelerAnotherDwight);
    priorities.printSchuelerList(newListOfSchuelerForTest);
}

//  Purpose: The following test covers the standard constructor as well as parsing the QUIT-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testParseQuitEvent() throw(std::runtime_error)
{
    EventTypes eventTypes;
    Priorities priorities;
    try
    {
        Event parsedEvent = priorities.parseEvent(eventTypes.getQuit());
        if (parsedEvent.getEventType() == eventTypes.getQuit())
        {
            std::cout << "PrioritiesTest::testParseQuitEvent(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testParseQuitEvent(): Test failed. Extracted event type differs from the initially given one.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testParseQuitEvent(): Test failed. The parsing went wrong.");
    }
}

//  Purpose: The following test covers the standard constructor as well as parsing the PRINT-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testParsePrintEvent() throw(std::runtime_error)
{
    EventTypes eventTypes;
    Priorities priorities;
    try
    {
        Event parsedEvent = priorities.parseEvent(eventTypes.getPrint());
        if (parsedEvent.getEventType() == eventTypes.getPrint())
        {
            std::cout << "PrioritiesTest::testParsePrintEvent(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testParsePrintEvent(): Test failed. Extracted event type differs from the initially given one.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testParsePrintEvent(): Test failed. The parsing went wrong.");
    }
}

//  Purpose: The following test covers the standard constructor as well as parsing the SERVED-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testParseServedEvent() throw(std::runtime_error)
{
    EventTypes eventTypes;
    Priorities priorities;
    try
    {
        Event parsedEvent = priorities.parseEvent(eventTypes.getServed());
        if (parsedEvent.getEventType() == eventTypes.getServed())
        {
            std::cout << "PrioritiesTest::testParseServedEvent(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testParseServedEvent(): Test failed. Extracted event type differs from the initially given one.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testParseServedEvent(): Test failed. The parsing went wrong.");
    }
}

//  Purpose: The following test covers the standard constructor as well as parsing the ENTER-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testParseEnterEvent() throw(std::runtime_error)
{
    EventTypes eventTypes;
    Priorities priorities;
    std::stringstream eventToBeParsed;
    eventToBeParsed << eventTypes.getEnter() << " Emily 1.24 24";
    try
    {
        Event parsedEvent = priorities.parseEvent(eventToBeParsed.str());
        bool doEventTypesMatch = (parsedEvent.getEventType() == eventTypes.getEnter());
        bool doNamesMatch = (parsedEvent.getSchueler().getName() == "Emily");
        bool doIdentifiersMatch = (parsedEvent.getSchueler().getId() == 24);
        bool doCgpasMatch = (parsedEvent.getSchueler().getCgpa() == 1.24);
        if (doEventTypesMatch == true && doNamesMatch == true && doIdentifiersMatch == true && doCgpasMatch == true)
        {
            std::cout << "PrioritiesTest::testParseEnterEvent(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testParseEnterEvent(): Test failed. Extracted pupil data differs from the initially given one.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testParseEnterEvent(): Test failed. The parsing went wrong.");
    }
}

//  Purpose: The following test covers the standard constructor as well as parsing an empty event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testParseEmptyEvent() throw(std::runtime_error)
{
    Priorities priorities;
    try
    {
        Event parsedEvent = priorities.parseEvent("");
        throw std::runtime_error("PrioritiesTest::testParseEmptyEvent(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testParseEmptyEvent(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as parsing an invalid event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testParseWrongEvent() throw(std::runtime_error)
{
    Priorities priorities;
    try
    {
        Event parsedEvent = priorities.parseEvent("Wrong event");
        throw std::runtime_error("PrioritiesTest::testParseWrongEvent(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testParseWrongEvent(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting an empty list of pupils by CGPAs, artificially given by data corruption.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortEmptyListByCgpa() throw(std::runtime_error)
{
    Priorities priorities;
    std::list<Schueler> emptyListOfSchuelerForTest;
    priorities.m_schuelerList = emptyListOfSchuelerForTest;
    try
    {
        priorities.sortByCgpa();
        throw std::runtime_error("PrioritiesTest::testSortEmptyListByCgpa(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testSortEmptyListByCgpa(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils with just one entry by CGPAs.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortAn1EntryListByCgpa() throw(std::runtime_error)
{
    Priorities priorities;
    std::list<Schueler> listOfSchuelerForTest;
    Schueler schueler(25, "Hank", 1.25);
    listOfSchuelerForTest.push_back(schueler);
    priorities.setSchuelerList(listOfSchuelerForTest);
    try
    {
        priorities.sortByCgpa();
        if (priorities.getIsListSortedByCgpa() == true)
        {
            std::cout << "PrioritiesTest::testSortAn1EntryListByCgpa(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testSortAn1EntryListByCgpa(): Test failed.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testSortAn1EntryListByCgpa(): Test failed. Sorting the list went wrong.");
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils by CGPAs.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortByCgpa() throw(std::runtime_error)
{
    Priorities priorities;
    Schueler schuelerLinda(11, "Linda", 1.11);
    Schueler schuelerJoe(12, "Joe", 1.12);
    Schueler schuelerAvril(13, "Avril", 1.22);
    std::list<Schueler> unsortedListOfSchuelerForTest;
    std::list<Schueler> expectedSortedListOfSchuelerForTest;
    unsortedListOfSchuelerForTest.push_back(schuelerLinda);
    unsortedListOfSchuelerForTest.push_back(schuelerAvril);
    unsortedListOfSchuelerForTest.push_back(schuelerJoe);
    expectedSortedListOfSchuelerForTest.push_back(schuelerAvril);
    expectedSortedListOfSchuelerForTest.push_back(schuelerJoe);
    expectedSortedListOfSchuelerForTest.push_back(schuelerLinda);
    priorities.setSchuelerList(unsortedListOfSchuelerForTest);
    priorities.sortByCgpa();
    if (areSchuelerListsEqual(expectedSortedListOfSchuelerForTest, priorities.getSchuelerList()) == true)
    {
        std::cout << "PrioritiesTest::testSortByCgpa(): Test passed.\n";
    }
    else
    {
        throw std::runtime_error("PrioritiesTest::testSortByCgpa(): Test failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting an empty list of pupils by names, artificially given by data corruption.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortEmptyListByNames() throw(std::invalid_argument)
{
    Priorities priorities;
    std::list<Schueler> emptyListOfSchuelerForTest;
    priorities.m_schuelerList = emptyListOfSchuelerForTest;
    priorities.setIsListSortedByCgpa(true);
    try
    {
        priorities.sortByNames();
        throw std::runtime_error("PrioritiesTest::testSortEmptyListByNames(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testSortEmptyListByNames(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils with just one entry by names.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortAn1EntryListByNames() throw(std::invalid_argument)
{
    Priorities priorities;
    std::list<Schueler> listOfSchuelerForTest;
    Schueler schueler(25, "Hank", 1.25);
    listOfSchuelerForTest.push_back(schueler);
    priorities.setSchuelerList(listOfSchuelerForTest);
    priorities.setIsListSortedByCgpa(true);
    try
    {
        priorities.sortByNames();
        if (priorities.getIsListSortedByNames() == true)
        {
            std::cout << "PrioritiesTest::testSortAn1EntryListByNames(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testSortAn1EntryListByNames(): Test failed.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testSortAn1EntryListByNames(): Test failed. Sorting the list went wrong.");
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils by names without sorting them by CGPA before, which represents a violation of priorities.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortUnsortedListByNames() throw(std::invalid_argument)
{
    Priorities priorities;
    Schueler schuelerLinda(11, "Linda", 1.11);
    Schueler schuelerJoe(12, "Joe", 1.12);
    Schueler schuelerAvril(13, "Avril", 1.22);
    std::list<Schueler> unsortedListOfSchuelerForTest;
    unsortedListOfSchuelerForTest.push_back(schuelerLinda);
    unsortedListOfSchuelerForTest.push_back(schuelerAvril);
    unsortedListOfSchuelerForTest.push_back(schuelerJoe);
    priorities.setSchuelerList(unsortedListOfSchuelerForTest);
    try
    {
        priorities.sortByNames();
        throw std::runtime_error("PrioritiesTest::testSortUnsortedListByNames(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testSortUnsortedListByNames(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils by names which is pre-sorted by CGPAs.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortByNames() throw(std::invalid_argument)
{
    Priorities priorities;
    Schueler schuelerAvril(13, "Avril", 1.22);
    Schueler schuelerLinda(11, "Linda", 1.11);
    Schueler schuelerJoe(12, "Joe", 1.11);
    std::list<Schueler> unsortedListOfSchuelerForTest;
    std::list<Schueler> expectedSortedListOfSchuelerForTest;
    unsortedListOfSchuelerForTest.push_back(schuelerAvril);
    unsortedListOfSchuelerForTest.push_back(schuelerLinda);
    unsortedListOfSchuelerForTest.push_back(schuelerJoe);
    expectedSortedListOfSchuelerForTest.push_back(schuelerAvril);
    expectedSortedListOfSchuelerForTest.push_back(schuelerJoe);
    expectedSortedListOfSchuelerForTest.push_back(schuelerLinda);
    priorities.setSchuelerList(unsortedListOfSchuelerForTest);
    priorities.setIsListSortedByCgpa(true);
    priorities.sortByNames();
    if (areSchuelerListsEqual(expectedSortedListOfSchuelerForTest, priorities.getSchuelerList()) == true)
    {
        std::cout << "PrioritiesTest::testSortByNames(): Test passed.\n";
    }
    else
    {
        throw std::runtime_error("PrioritiesTest::testSortByNames(): Test failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting an empty list of pupils by identifiers, artificially given by data corruption.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testEmptyListSortByIdentifiers() throw(std::invalid_argument)
{
    Priorities priorities;
    std::list<Schueler> emptyListOfSchuelerForTest;
    priorities.m_schuelerList = emptyListOfSchuelerForTest;
    priorities.setIsListSortedByCgpa(true);
    priorities.setIsListSortedByNames(true);
    try
    {
        priorities.sortByIdentifiers();
        throw std::runtime_error("PrioritiesTest::testEmptyListSortByIdentifiers(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testEmptyListSortByIdentifiers(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils with just one entry by identifiers.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortAn1EntryListByIdentifiers() throw(std::invalid_argument)
{
    Priorities priorities;
    std::list<Schueler> listOfSchuelerForTest;
    Schueler schueler(25, "Hank", 1.25);
    listOfSchuelerForTest.push_back(schueler);
    priorities.setSchuelerList(listOfSchuelerForTest);
    priorities.setIsListSortedByCgpa(true);
    priorities.setIsListSortedByNames(true);
    try
    {
        priorities.sortByIdentifiers();
        if (priorities.getIsListSortedByIdentifier() == true)
        {
            std::cout << "PrioritiesTest::testSortAn1EntryListByIdentifiers(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testSortAn1EntryListByIdentifiers(): Test failed.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testSortAn1EntryListByIdentifiers(): Test failed. Sorting the list went wrong.");
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils by identifiers without sorting them by CGPA or names, respectively, before, which represents a violation of priorities.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortUnsortedListByIdentifiers() throw(std::invalid_argument)
{
    Priorities priorities;
    Schueler schuelerLinda(11, "Linda", 1.11);
    Schueler schuelerJoe(12, "Joe", 1.12);
    Schueler schuelerAvril(13, "Avril", 1.22);
    std::list<Schueler> unsortedListOfSchuelerForTest;
    unsortedListOfSchuelerForTest.push_back(schuelerLinda);
    unsortedListOfSchuelerForTest.push_back(schuelerAvril);
    unsortedListOfSchuelerForTest.push_back(schuelerJoe);
    priorities.setSchuelerList(unsortedListOfSchuelerForTest);
    try
    {
        priorities.sortByIdentifiers();
        throw std::runtime_error("PrioritiesTest::testSortUnsortedListByIdentifiers(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testSortUnsortedListByIdentifiers(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils by names which is consecutively pre-sorted by both, CGPAs and names.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortByIdentifiers() throw(std::invalid_argument)
{
    Priorities priorities;
    Schueler schuelerAvril(13, "Avril", 1.22);
    Schueler schuelerAnotherJoe(12, "Joe", 1.11);
    Schueler schuelerJoe(11, "Joe", 1.11);
    std::list<Schueler> unsortedListOfSchuelerForTest;
    std::list<Schueler> expectedSortedListOfSchuelerForTest;
    unsortedListOfSchuelerForTest.push_back(schuelerAvril);
    unsortedListOfSchuelerForTest.push_back(schuelerAnotherJoe);
    unsortedListOfSchuelerForTest.push_back(schuelerJoe);
    expectedSortedListOfSchuelerForTest.push_back(schuelerAvril);
    expectedSortedListOfSchuelerForTest.push_back(schuelerJoe);
    expectedSortedListOfSchuelerForTest.push_back(schuelerAnotherJoe);
    priorities.setSchuelerList(unsortedListOfSchuelerForTest);
    priorities.setIsListSortedByCgpa(true);
    priorities.setIsListSortedByNames(true);
    priorities.sortByIdentifiers();
    if (areSchuelerListsEqual(expectedSortedListOfSchuelerForTest, priorities.getSchuelerList()) == true)
    {
        std::cout << "PrioritiesTest::testSortByIdentifiers(): Test passed.\n";
    }
    else
    {
        throw std::runtime_error("PrioritiesTest::testSortByIdentifiers(): Test failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting an empty list of pupils by priorities, artificially given by data corruption.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortEmptyListByPriorities() throw(std::invalid_argument)
{
    Priorities priorities;
    std::list<Schueler> emptyListOfSchuelerForTest;
    priorities.m_schuelerList = emptyListOfSchuelerForTest;
    try
    {
        priorities.sortByCgpa();
        throw std::runtime_error("PrioritiesTest::testSortEmptyListByPriorities(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testSortEmptyListByPriorities(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils with just one entry by priorities, which is consecutively by CGPAs, names and identifiers.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortAn1EntryListByPriorities() throw(std::invalid_argument)
{
    Priorities priorities;
    std::list<Schueler> listOfSchuelerForTest;
    Schueler schueler(25, "Hank", 1.25);
    listOfSchuelerForTest.push_back(schueler);
    priorities.setSchuelerList(listOfSchuelerForTest);
    try
    {
        priorities.sortByPriorities();
        if (priorities.getIsListSortedByCgpa() == false && priorities.getIsListSortedByNames() == false && priorities.getIsListSortedByIdentifier() == false)
        {
            std::cout << "PrioritiesTest::testSortAn1EntryListByPriorities(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testSortAn1EntryListByPriorities(): Test failed.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testSortAn1EntryListByPriorities(): Test failed. Sorting the list went wrong.");
    }
}

//  Purpose: The following test covers the standard constructor as well as sorting a list of pupils by priorities.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testSortByPriorities() throw(std::invalid_argument)
{
    Priorities priorities;
    Schueler schuelerMiranda(27, "Miranda", 1.30);
    Schueler schuelerTimmy(28, "Timmy", 1.11);
    Schueler schuelerJoe(29, "Joe", 1.29);
    Schueler schuelerAnotherMiranda(30, "Miranda", 1.30);
    std::list<Schueler> unsortedListOfSchuelerForTest;
    std::list<Schueler> expectedSortedListOfSchuelerForTest;
    unsortedListOfSchuelerForTest.push_back(schuelerMiranda);
    unsortedListOfSchuelerForTest.push_back(schuelerTimmy);
    unsortedListOfSchuelerForTest.push_back(schuelerJoe);
    unsortedListOfSchuelerForTest.push_back(schuelerAnotherMiranda);
    expectedSortedListOfSchuelerForTest.push_back(schuelerMiranda);
    expectedSortedListOfSchuelerForTest.push_back(schuelerAnotherMiranda);
    expectedSortedListOfSchuelerForTest.push_back(schuelerJoe);
    expectedSortedListOfSchuelerForTest.push_back(schuelerTimmy);
    priorities.setSchuelerList(unsortedListOfSchuelerForTest);
    priorities.sortByPriorities();
    if (areSchuelerListsEqual(expectedSortedListOfSchuelerForTest, priorities.getSchuelerList()) == true)
    {
        std::cout << "PrioritiesTest::testSortByPriorities(): Test passed.\n";
    }
    else
    {
        throw std::runtime_error("PrioritiesTest::testSortByPriorities(): Test failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as the execution of getSchuelers with an empty list of events.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testGetSchuelersWithEmptyEvent() throw(std::invalid_argument)
{
    Priorities priorities;
    std::list<std::string> emptyEventList;
    try
    {
        priorities.getSchuelers(emptyEventList);
        throw std::runtime_error("PrioritiesTest::testGetSchuelersWithEmptyEvent(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "PrioritiesTest::testGetSchuelersWithEmptyEvent(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as the execution of getSchuelers with an list of events containing the QUIT-event. Since this event halts this application immediately, this test is commented out in order to enable performing all the other tests and not to halt the application, if further operation is desired after a full self-test.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testGetSchuelersWithQuitEvent() throw(std::invalid_argument)
{
    Priorities priorities;
    EventTypes eventTypes;
    std::list<std::string> eventListWithQuitEvent;
    eventListWithQuitEvent.push_back(eventTypes.getQuit());
    try
    {
        priorities.getSchuelers(eventListWithQuitEvent);
        std::cout << "PrioritiesTest::testGetSchuelersWithQuitEvent(): Test passed, although this code is never reached.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testGetSchuelersWithQuitEvent(): Test failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as the execution of getSchuelers with an list of events containing the PRINT-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testGetSchuelersWithPrintEvent() throw(std::invalid_argument)
{
    Priorities priorities;
    EventTypes eventTypes;
    std::list<std::string> eventListWithPrintEvent;
    eventListWithPrintEvent.push_back(eventTypes.getPrint());
    try
    {
        priorities.getSchuelers(eventListWithPrintEvent);
        std::cout << "PrioritiesTest::testGetSchuelersWithPrintEvent(): Test passed.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testGetSchuelersWithPrintEvent(): Test failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as the execution of getSchuelers with an list of events containing just the SERVED-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testGetSchuelersWithServedEventOnEmptyList() throw(std::invalid_argument)
{
    Priorities priorities;
    EventTypes eventTypes;
    std::list<std::string> eventListJustWithServedEvent;
    eventListJustWithServedEvent.push_back(eventTypes.getPrint());
    try
    {
        priorities.getSchuelers(eventListJustWithServedEvent);
        std::cout << "PrioritiesTest::testGetSchuelersWithServedEventOnEmptyList(): Test passed.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testGetSchuelersWithServedEventOnEmptyList(): Test failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as the execution of getSchuelers with an list of events containing the SERVED-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testGetSchuelersWithServedEventOnFilledList() throw(std::invalid_argument)
{
    Priorities priorities;
    EventTypes eventTypes;
    Schueler schueler(31, "Ray", 1.31);
    std::list<Schueler> newListOfSchueler;
    std::list<std::string> eventListWithServedEvent;
    newListOfSchueler.push_back(schueler);
    priorities.setSchuelerList(newListOfSchueler);
    eventListWithServedEvent.push_back(eventTypes.getServed());
    try
    {
        priorities.getSchuelers(eventListWithServedEvent);
        if (priorities.getSchuelerList().empty() == true)
        {
            std::cout << "PrioritiesTest::testGetSchuelersWithServedEventOnFilledList(): Test passed.\n";
        }
        else
        {
            throw std::runtime_error("PrioritiesTest::testGetSchuelersWithServedEventOnFilledList(): Test failed. The list of pupils still contains an entry.");
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testGetSchuelersWithServedEventOnFilledList(): Test failed. The execution of the method getSchuelers() failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as the execution of getSchuelers with an list of events containing the ENTER-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testGetSchuelersWithEnterEventOnEmptyList() throw(std::invalid_argument)
{
    Priorities priorities;
    EventTypes eventTypes;
    Schueler schueler(32, "Peggy", 1.32);
    std::stringstream enterEvent;
    enterEvent << eventTypes.getEnter() << " " << schueler.getName() << " " << schueler.getCgpa() << " " << schueler.getId();
    std::list<std::string> eventListWithEnterEvent;
    priorities.eraseSchuelerList();
    eventListWithEnterEvent.push_back(enterEvent.str());
    try
    {
        std::list<Schueler> actualSchuelerList = priorities.getSchuelers(eventListWithEnterEvent);
        if (actualSchuelerList.size() == 1 && actualSchuelerList.front().equalsTo(schueler) == true)
        {
            std::cout << "PrioritiesTest::testGetSchuelersWithEnterEventOnEmptyList(): Test passed.\n";
        }
        else
        {
            std::stringstream errorMessage;
            errorMessage << "PrioritiesTest::testGetSchuelersWithEnterEventOnEmptyList(): Test failed. The list of pupils is either longer than 1 or the pupil's data doesn't match. size = " << actualSchuelerList.size() << ", expected pupil's data = " << schueler.convertToString() << ", actual pupil's data = " << actualSchuelerList.front().convertToString();
            throw std::runtime_error(errorMessage.str());
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testGetSchuelersWithEnterEventOnEmptyList(): Test failed. The execution of the method getSchuelers() failed.");
    }
}

//  Purpose: The following test covers the standard constructor as well as the execution of getSchuelers with an list of events containing the ENTER-event.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::testGetSchuelersWithEnterEventOnFilledList() throw(std::invalid_argument)
{
    Priorities priorities;
    EventTypes eventTypes;
    Schueler alreadyExistingSchueler(33, "Chester", 1.33);
    Schueler newSchueler(34, "Amy", 1.34);
    std::stringstream enterEvent;
    std::list<std::string> eventListWithEnterEvent;
    std::list<Schueler> alreadyExistingSchuelerList;
    enterEvent << eventTypes.getEnter() << " " << newSchueler.getName() << " " << newSchueler.getCgpa() << " " << newSchueler.getId();
    alreadyExistingSchuelerList.push_back(alreadyExistingSchueler);
    eventListWithEnterEvent.push_back(enterEvent.str());
    priorities.setSchuelerList(alreadyExistingSchuelerList);
    try
    {
        std::list<Schueler> actualSchuelerList = priorities.getSchuelers(eventListWithEnterEvent);
        bool isSize2 = (actualSchuelerList.size() == 2);
        bool isChesterThere = (actualSchuelerList.back().equalsTo(alreadyExistingSchueler) == true);
        bool isAmyThere = (actualSchuelerList.front().equalsTo(newSchueler) == true);
        if (isSize2 == true && isChesterThere == true && isAmyThere == true)
        {
            std::cout << "PrioritiesTest::testGetSchuelersWithEnterEventOnFilledList(): Test passed.\n";
        }
        else
        {
            std::stringstream errorMessage;
            errorMessage << "PrioritiesTest::testGetSchuelersWithEnterEventOnFilledList(): Test failed. The list of pupils either differs from 2 or the pupil's data doesn't match. size = " << actualSchuelerList.size() << ", expected pupil's data (1) = " << alreadyExistingSchueler.convertToString() << ", actual pupil's data (1) = " << actualSchuelerList.back().convertToString() <<  ", expected pupil's data (2) = " << newSchueler.convertToString() << ", actual pupil's data (2) = " << actualSchuelerList.front().convertToString();
            throw std::runtime_error(errorMessage.str());
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("PrioritiesTest::testGetSchuelersWithEnterEventOnFilledList(): Test failed. The execution of the method getSchuelers() failed.");
    }
}

//  Purpose: The following test aggregates all tests of this class. Since the QUIT-event halts this application immediately, the corresponding test is commented out in order to enable performing all the other tests and not to halt the application, if further operation is desired after a full self-test.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PrioritiesTest::runAllTests() throw(std::runtime_error)
{
    testSetSchuelerList();
    testSetWrongSchuelerList();
    testGetSchuelerList();
    testEraseSchuelerList();
    testPrintSchuelerList();
    testParseQuitEvent();
    testParsePrintEvent();
    testParseServedEvent();
    testParseEnterEvent();
    testParseEmptyEvent();
    testParseWrongEvent();
    testSortEmptyListByCgpa();
    testSortAn1EntryListByCgpa();
    testSortByCgpa();
    testSortEmptyListByNames();
    testSortAn1EntryListByNames();
    testSortUnsortedListByNames();
    testSortByNames();
    testEmptyListSortByIdentifiers();
    testSortAn1EntryListByIdentifiers();
    testSortUnsortedListByIdentifiers();
    testSortByIdentifiers();
    testSortEmptyListByPriorities();
    testSortAn1EntryListByPriorities();
    testSortByPriorities();
    testGetSchuelersWithEmptyEvent();
    //testGetSchuelersWithQuitEvent();
    testGetSchuelersWithPrintEvent();
    testGetSchuelersWithServedEventOnEmptyList();
    testGetSchuelersWithServedEventOnFilledList();
    testGetSchuelersWithEnterEventOnEmptyList();
    testGetSchuelersWithEnterEventOnFilledList();
    std::cout << "PrioritiesTest::runAllTests(): All tests ran sucessfully.\n";
}
