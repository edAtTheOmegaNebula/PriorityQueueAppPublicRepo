//  Event.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class models an event in order to control this application.
//  Reason: Objects of this class evaluate the priority of pupils to manage.
//  Author: Edhem Bajrić
//  Date: 15.05.2020

#ifndef Event_h
#define Event_h

#include <stdexcept>
#include "Schueler.h"
#include "EventTypes.h"

class Event
{
    friend class EventTest;
public:
    Event(std::string newEventType) throw(std::invalid_argument);
    Event(std::string newEventType, Schueler newSchueler) throw(std::invalid_argument);
    Schueler getSchueler() throw(std::invalid_argument);
    std::string getEventType() throw(std::invalid_argument);
private:
    std::string m_eventType;
    Schueler m_Schueler;
    void setEventType(std::string newEventType) throw(std::invalid_argument);
    void setSchueler(Schueler newSchueler) throw(std::invalid_argument);
};

#endif /* Event_h */
