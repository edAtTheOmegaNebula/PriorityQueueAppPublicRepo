//  Schueler.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include "Schueler.h"

//  Purpose: The following constructor creates an instance of this class.
//  Reason: Objects of this class are needed for processing pupils by priority.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Throws: std::invalid_argument
Schueler::Schueler(int id, std::string name, double cgpa) throw(std::invalid_argument)
{
    setId(id);
    setName(name);
    setCgpa(cgpa);
}

//  Purpose: The following constructor creates an default dummy instance of this class.
//  Reason: Test purposes.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Throws: std::invalid_argument
Schueler::Schueler() throw(std::invalid_argument)
{
    setId(9876);
    setName("Charles");
    setCgpa(3.21);
}

//  Purpose: The following method returns the identifier of a pupil.
//  Reason: The method protects the appropriate field from corruption.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Returns: int identifier
//  Throws: std::invalid_argument
int Schueler::getId() throw(std::invalid_argument)
{
    if (m_id < m_idMin || m_id > m_idMax)
    {
        throw std::invalid_argument("Schueler::getId(): Identifier has an corrupted value. It has to be within [0,100000].");
    }
    else
    {
        return m_id;
    }
}

//  Purpose: The following method sets the identifier of a pupil.
//  Reason: The identifiers are modelled by positive natural numbers less than or equal to 100000 and have therefore to be checked both, at their input and output.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: int newId in [0,100000]
//  Throws: std::invalid_argument
void Schueler::setId(int newId) throw(std::invalid_argument)
{
    if (newId < m_idMin || newId > m_idMax)
    {
        throw std::invalid_argument("Schueler::setId(int newId = " + std::to_string(newId) + "): Identifier has to be within [0,100000].");
    }
    else
    {
        m_id = newId;
    }
}

//  Purpose: The following method returns the name of a pupil.
//  Reason: The method protects the appropriate field from corruption.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Throws: std::invalid_argument
std::string Schueler::getName() throw(std::invalid_argument)
{
    bool isFirstMajusculeRestMinuscules = std::regex_match(m_name, std::regex("^[A-Z]{1}[a-z]{1,29}$"));
    if (isFirstMajusculeRestMinuscules == true)
    {
        return m_name;
    }
    else
    {
        throw std::invalid_argument("Schueler::getName(): The name is corrupted.");
    }
}

//  Purpose: The following method sets the identifier of a pupil. A pupil is expected to write its name properly. A name of a pupil as natural person is its latin transcription, begins with a majuscule, followed by minuscules only and just uses the letters A-Z and a-z, respectively. The name is expected to be the first name, since the example of the specification suggests this. Latin transcriptions of double names, forenames with lastnames, names with umlauts or names with more than one majuscule, like McDonald are not accepted.
//  Reason: The natural names do allow just characters.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::string newName (just letters by criteria above)
//  Throws: std::invalid_argument
void Schueler::setName(std::string newName) throw(std::invalid_argument)
{
    bool isFirstMajusculeRestMinuscules = std::regex_match(newName, std::regex("^[A-Z]{1}[a-z]{1,29}$"));
    if (isFirstMajusculeRestMinuscules == true)
    {
        m_name = newName;
    }
    else
    {
        throw std::invalid_argument("Schueler::setName(std::string = " + newName + "): The name has to begin with a majuscule and contain just minuscules for the rest.");
    }
}

//  Purpose: The following method sets the identifier of a pupil.
//  Reason: The CGPA is modelled by positive decimal numbers less than or equal to 4 and have therefore to be checked both, at their input and output.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Returns: double CGPA
//  Throws: std::invalid_argument
double Schueler::getCgpa() throw(std::invalid_argument)
{
    if (m_cgpa < m_cgpaMin || m_cgpa > m_cgpaMax)
    {
        throw std::invalid_argument("Schueler::getCgpa(): CGPA has an corrupted value. It has to be within [0,4].");
    }
    else
    {
        return m_cgpa;
    }
}

//  Purpose: The following method sets the identifier of a pupil.
//  Reason: The CGPA is modelled by positive decimal numbers less than or equal to 4 and have therefore to be checked both, at their input and output.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: double newCgpa in [0,4]
//  Throws: std::invalid_argument
void Schueler::setCgpa(double newCgpa) throw(std::invalid_argument)
{
    if (newCgpa < m_cgpaMin || newCgpa > m_cgpaMax)
    {
        throw std::invalid_argument("Schueler::setCgpa(double newCgpa = " + std::to_string(newCgpa) + "): CGPA has to be within [0,4].");
    }
    else
    {
        m_cgpa = newCgpa;
    }
}


//  Purpose: The following method sets the identifier of a pupil.
//  Reason: The CGPA is modelled by positive decimal numbers less than or equal to 4 and have therefore to be checked both, at their input and output.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: double newCgpa in [0,4]
//  Throws: std::invalid_argument
std::string Schueler::convertToString() throw(std::invalid_argument)
{
    std::stringstream stringStream;
    stringStream << "Pupil: Name = " << getName() << ", ID = " << getId() << ", CGPA = " << getCgpa() << ".";
    return stringStream.str();
}

//  Purpose: The following method tells, whether two objects of this class do have identical data or not.
//  Reason: Ease of test assertions.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Parameters: Schueler newSchueler
bool Schueler::equalsTo(Schueler newSchueler)
{
    bool doNamesMatch = (getName() == newSchueler.getName());
    bool doCgpasMatch = (getCgpa() == newSchueler.getCgpa());
    bool doIdsMatch = (getId() == newSchueler.getId());
    if (doCgpasMatch == true && doNamesMatch == true && doIdsMatch == true)
    {
        return true;
    }
    else
    {
        return false;
    }
}
