//  PriorityQueueAppTester.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 17.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include "PriorityQueueAppTester.h"

//  Purpose: The following method aggregates all tests of this software to be run automatically on demand. A successful test run looks like this:
//      void PriorityQueueAppTester::runAllTests(): Start.
//      SchuelerTest::testStandardConstructorAndCorrectlyUsedIdNameCgpaSetters(): Test passed.
//      SchuelerTest::testExplicitConstructorAndWronglySetId(): Test passed.
//      SchuelerTest::testSetWrongName(): Test passed.
//      SchuelerTest::testSetWrongCgpa(): Test passed.
//      SchuelerTest::testGetId(): Test passed.
//      SchuelerTest::testGetWrongId(): Test passed.
//      SchuelerTest::testGetName(): Test passed.
//      SchuelerTest::testGetWrongName(): Test passed.
//      SchuelerTest::testGetCgpa(): Test passed.
//      SchuelerTest::testGetWrongCgpa(): Test passed.
//      SchuelerTest::testConvertToString(): Test passed.
//      SchuelerTest::testEqualsToIdentity(): Test passed.
//      SchuelerTest::testEqualsToDiversity(): Test passed.
//      SchuelerTest::runAllTests(): All tests ran sucessfully.
//      EventTypesTest::testStandardConstructorAndCorrectlyUsedEnterQuitServedPrintSetters(): Test passed.
//      EventTypesTest::testSetWrongEnter(): Test passed.
//      EventTypesTest::testSetWrongQuit(): Test passed.
//      EventTypesTest::testSetWrongServed(): Test passed.
//      EventTypesTest::testSetWrongPrint(): Test passed.
//      EventTypesTest::testGetEnter(): Test passed.
//      EventTypesTest::testGetWrongEnter(): Test passed.
//      EventTypesTest::testGetQuit(): Test passed.
//      EventTypesTest::testGetWrongQuit(): Test passed.
//      EventTypesTest::testGetServed(): Test passed.
//      EventTypesTest::testGetWrongServed(): Test passed.
//      EventTypesTest::testGetPrint(): Test passed.
//      EventTypesTest::testGetWrongPrint(): Test passed.
//      EventTypesTest::runAllTests(): All tests ran sucessfully.
//      EventTest::testConstructorForQuitEventsAndCorrectlyUsedEventTypeSetter(): Test passed.
//      EventTest::testConstructorForPrintEventsAndCorrectlyUsedEventTypeSetter(): Test passed.
//      EventTest::testConstructorForServedEventsAndCorrectlyUsedEventTypeSetter(): Test passed.
//      EventTest::testExplicitConstructorForEnterEventAndCorrectlyUsedEventTypeSchuelerSetters(): Test passed.
//      EventTest::testSetWrongEventType(): Test passed.
//      EventTest::testGetEventType(): Test passed.
//      EventTest::testGetWrongEventType(): Test passed.
//      EventTest::testGetSchueler(): Test passed.
//      EventTest::runAllTests(): All tests ran sucessfully.
//      PrioritiesTest::testSetSchuelerList(): Test passed.
//      PrioritiesTest::testSetWrongSchuelerList(): Test passed.
//      PrioritiesTest::testGetSchuelerList(): Test passed.
//      PrioritiesTest::testEraseSchuelerList(): Test passed.
//      Pupil: Name = Linda, ID = 11, CGPA = 1.11.
//      Pupil: Name = Joe, ID = 12, CGPA = 1.12.
//      Pupil: Name = Avril, ID = 13, CGPA = 1.22.
//      Pupil: Name = Dwight, ID = 14, CGPA = 1.14.
//      Pupil: Name = Oprah, ID = 15, CGPA = 1.15.
//      Pupil: Name = Antony, ID = 16, CGPA = 1.16.
//      Pupil: Name = Beth, ID = 17, CGPA = 1.17.
//      Pupil: Name = Louie, ID = 18, CGPA = 1.11.
//      Pupil: Name = Betty, ID = 19, CGPA = 1.19.
//      Pupil: Name = Lee, ID = 20, CGPA = 1.2.
//      Pupil: Name = Tracy, ID = 21, CGPA = 1.21.
//      Pupil: Name = Louie, ID = 22, CGPA = 1.22.
//      Pupil: Name = Beth, ID = 17, CGPA = 1.23.
//      Pupil: Name = Dwight, ID = 23, CGPA = 1.14.
//      PrioritiesTest::testParseQuitEvent(): Test passed.
//      PrioritiesTest::testParsePrintEvent(): Test passed.
//      PrioritiesTest::testParseServedEvent(): Test passed.
//      PrioritiesTest::testParseEnterEvent(): Test passed.
//      PrioritiesTest::testParseEmptyEvent(): Test passed.
//      PrioritiesTest::testParseWrongEvent(): Test passed.
//      PrioritiesTest::testSortEmptyListByCgpa(): Test passed.
//      Priorities::sortByCgpa(): The list of pupils remains the same, since it has just one entry.
//      PrioritiesTest::testSortAn1EntryListByCgpa(): Test passed.
//      PrioritiesTest::testSortByCgpa(): Test passed.
//      PrioritiesTest::testSortEmptyListByNames(): Test passed.
//      Priorities::sortByNames(): The list of pupils remains the same, since it has just one entry.
//      PrioritiesTest::testSortAn1EntryListByNames(): Test passed.
//      PrioritiesTest::testSortUnsortedListByNames(): Test passed.
//      PrioritiesTest::testSortByNames(): Test passed.
//      PrioritiesTest::testEmptyListSortByIdentifiers(): Test passed.
//      Priorities::sortByIdentifiers(): The list of pupils remains the same, since it has just one entry.
//      PrioritiesTest::testSortAn1EntryListByIdentifiers(): Test passed.
//      PrioritiesTest::testSortUnsortedListByIdentifiers(): Test passed.
//      PrioritiesTest::testSortByIdentifiers(): Test passed.
//      PrioritiesTest::testSortEmptyListByPriorities(): Test passed.
//      Priorities::sortByCgpa(): The list of pupils remains the same, since it has just one entry.
//      PrioritiesTest::testSortAn1EntryListByPriorities(): Test passed.
//      PrioritiesTest::testSortByPriorities(): Test passed.
//      PrioritiesTest::testGetSchuelersWithEmptyEvent(): Test passed.
//      void Priorities::printSchuelerList(std::list<Schueler> schuelerListToPrint): The given list is empty.
//      PrioritiesTest::testGetSchuelersWithPrintEvent(): Test passed.
//      void Priorities::printSchuelerList(std::list<Schueler> schuelerListToPrint): The given list is empty.
//      PrioritiesTest::testGetSchuelersWithServedEventOnEmptyList(): Test passed.
//      PrioritiesTest::testGetSchuelersWithServedEventOnFilledList(): Test passed.
//      void Priorities::eraseSchuelerList(): The list of pupils is already empty.
//      PrioritiesTest::testGetSchuelersWithEnterEventOnEmptyList(): Test passed.
//      PrioritiesTest::testGetSchuelersWithEnterEventOnFilledList(): Test passed.
//      PrioritiesTest::runAllTests(): All tests ran sucessfully.
//      void PriorityQueueAppTester::runAllTests(): End.
//      Program ended with exit code: 0
//  Reason: Minimizing amount of code in the method main().
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void PriorityQueueAppTester::runAllTests() throw(std::runtime_error)
{
    std::cout << "void PriorityQueueAppTester::runAllTests(): Start.\n";
    SchuelerTest schuelerTest;
    EventTypesTest eventTypesTest;
    EventTest eventTest;
    PrioritiesTest prioritiesTest;
    schuelerTest.runAllTests();
    eventTypesTest.runAllTests();
    eventTest.runAllTests();
    prioritiesTest.runAllTests();
    std::cout << "void PriorityQueueAppTester::runAllTests(): End.\n";
}
