//  main.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajrić on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//
//  Some sample usecases look like this:
//      Welcome to the PriorityQueue application 1.0.0. Please enter one of the following commands:
//      QUIT
//      PRINT
//      SERVED
//      ENTER <the pupil's name> <the pupil's CGPA> <the pupil's ID>
//      PRINT
//      void Priorities::printSchuelerList(std::list<Schueler> schuelerListToPrint): The given list is empty.
//
//      ENTER Pierce 1.23 89
//
//      PRINT
//      Pupil: Name = Pierce, ID = 89, CGPA = 1.23.
//
//      ENTER Lou 2.01 77
//
//      PRINT
//      Pupil: Name = Lou, ID = 77, CGPA = 2.01.
//      Pupil: Name = Pierce, ID = 89, CGPA = 1.23.
//
//      ENTER Stanley 1.51 200
//
//      PRINT
//      Pupil: Name = Lou, ID = 77, CGPA = 2.01.
//      Pupil: Name = Stanley, ID = 200, CGPA = 1.51.
//      Pupil: Name = Pierce, ID = 89, CGPA = 1.23.
//
//      ENTER Mary 1.23 33
//
//      PRINT
//      Pupil: Name = Lou, ID = 77, CGPA = 2.01.
//      Pupil: Name = Stanley, ID = 200, CGPA = 1.51.
//      Pupil: Name = Mary, ID = 33, CGPA = 1.23.
//      Pupil: Name = Pierce, ID = 89, CGPA = 1.23.
//
//      ENTER Stanley 1.51 3
//
//      PRINT
//      Pupil: Name = Lou, ID = 77, CGPA = 2.01.
//      Pupil: Name = Stanley, ID = 3, CGPA = 1.51.
//      Pupil: Name = Stanley, ID = 200, CGPA = 1.51.
//      Pupil: Name = Mary, ID = 33, CGPA = 1.23.
//      Pupil: Name = Pierce, ID = 89, CGPA = 1.23.
//
//      SERVED
//
//      PRINT
//      Pupil: Name = Stanley, ID = 3, CGPA = 1.51.
//      Pupil: Name = Stanley, ID = 200, CGPA = 1.51.
//      Pupil: Name = Mary, ID = 33, CGPA = 1.23.
//      Pupil: Name = Pierce, ID = 89, CGPA = 1.23.
//
//      SERVED
//
//      PRINT
//      Pupil: Name = Stanley, ID = 200, CGPA = 1.51.
//      Pupil: Name = Mary, ID = 33, CGPA = 1.23.
//      Pupil: Name = Pierce, ID = 89, CGPA = 1.23.
//
//      QUIT
//      Priorities::getSchuelers(std::list<std::string> events): QUIT-event detected. This application is halted immediately.
//      Program ended with exit code: 0

#include <iostream>
#include "PriorityQueueAppTester.h"

int main(int argc, const char * argv[])
{
    PriorityQueueAppTester priorityQueueAppTester;
    priorityQueueAppTester.runAllTests();
    Priorities priorities;
    std::cout << "Welcome to the PriorityQueue application 1.0.0. Please enter one of the following commands:\n\tQUIT\n\tPRINT\n\tSERVED\n\tENTER <the pupil's name> <the pupil's CGPA> <the pupil's ID>\n";
    while (true)
    {
        std::string usersCommand;
        std::list<std::string> listOfUserCommands;
        std::list<Schueler> listOfSchueler;
        getline(std::cin, usersCommand);
        listOfUserCommands.push_back(usersCommand);
        listOfSchueler = priorities.getSchuelers(listOfUserCommands);
        std::cout << "\n";
    }
    return 0;
}
