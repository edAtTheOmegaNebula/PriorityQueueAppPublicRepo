//  EventTypes.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class models different types of events.
//  Reason: Centralisation of the event types for assignment, comparison or displaying.
//  Author: Edhem Bajrić
//  Date: 15.05.2020

#ifndef EventTypes_h
#define EventTypes_h

#include <iostream>
#include <stdexcept>

class EventTypes
{
    friend class EventTypesTest;
public:
    EventTypes() throw(std::invalid_argument);
    std::string getEnter() throw(std::invalid_argument);
    std::string getQuit() throw(std::invalid_argument);
    std::string getServed() throw(std::invalid_argument);
    std::string getPrint() throw(std::invalid_argument);
private:
    void setEnter(std::string newEnterEvent) throw(std::invalid_argument);
    void setQuit(std::string newQuitEvent) throw(std::invalid_argument);
    void setServed(std::string newServedEvent) throw(std::invalid_argument);
    void setPrint(std::string newPrintEvent) throw(std::invalid_argument);
    std::string m_enterNewPupilEntry;
    std::string m_quitApplication;
    std::string m_highestPrioritizedServed;
    std::string m_printPendingPupilEntries;
};

#endif /* EventTypes_h */
