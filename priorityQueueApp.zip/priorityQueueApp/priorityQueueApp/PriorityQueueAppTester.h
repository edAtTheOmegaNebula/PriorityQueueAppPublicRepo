//  PriorityQueueAppTester.h
//  priorityQueueApp
//
//  Created by Edhem Bajric on 17.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.
//  Purpose: The following class bundles all tests of all classes of this software to be optionally executed in terms of a self-test.
//  Reason: Test automation.
//  Author: Edhem Bajrić
//  Date: 17.05.2020

#ifndef PriorityQueueAppTester_h
#define PriorityQueueAppTester_h

#include <stdio.h>
#include <stdexcept>
#include "SchuelerTest.h"
#include "EventTypesTest.h"
#include "EventTest.h"
#include "PrioritiesTest.h"

class PriorityQueueAppTester
{
public:
    void runAllTests() throw(std::runtime_error);
};

#endif /* PriorityQueueAppTester_h */
