//  Event.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include <stdio.h>
#include "Event.h"

//  Purpose: The following method constructs an instance of this class for the events QUIT, PRINT and SERVED.
//  Reason: The meant events do not require pupil data. Thus, this data is neither set, nor interpreted later on.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Parameters: std::string newEventType
//  Throws: std::invalid_argument
Event::Event(std::string newEventType) throw(std::invalid_argument)
{
    setEventType(newEventType);
}

//  Purpose: The following method constructs an instance of this class.
//  Reason: Aggregation of event identifiers and the corresponding information of a pupil.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::string newEventType, Schueler newSchueler
//  Throws: std::invalid_argument
Event::Event(std::string newEventType, Schueler newSchueler) throw(std::invalid_argument)
{
    setEventType(newEventType);
    setSchueler(newSchueler);
}

//  Purpose: The following method returns the object modelling a pupil.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Returns: Schueler object
//  Throws: std::invalid_argument
Schueler Event::getSchueler() throw(std::invalid_argument)
{
    return m_Schueler;
}

//  Purpose: The following method sets the event type of the parsed event.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::string newEventType
//  Throws: std::invalid_argument
void Event::setEventType(std::string newEventType) throw(std::invalid_argument)
{
    EventTypes eventTypes;
    if (newEventType.empty() == true)
    {
        throw std::invalid_argument("Event::setEventType(std::string newEventType = ''): The new event type has to contain any valid value.");
    }
    else if (newEventType != eventTypes.getQuit() && newEventType != eventTypes.getPrint() && newEventType != eventTypes.getServed() && newEventType != eventTypes.getEnter())
    {
        throw std::invalid_argument("Event::setEventType(std::string newEventType = ''): The new event type has to contain a valid value, which is one of " + eventTypes.getQuit() + ", " + eventTypes.getPrint() + ", " + eventTypes.getServed() + " or " + eventTypes.getEnter() + ".");
    }
    else
    {
        m_eventType = newEventType;
    }
}

//  Purpose: The following method returns the event type of the given user command.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Returns: std::string event type
//  Throws: std::invalid_argument
std::string Event::getEventType() throw(std::invalid_argument)
{
    EventTypes eventTypes;
    if (m_eventType.empty() == true)
    {
        throw std::invalid_argument("Event::getEventType(): The event type is corrupted.");
    }
    else if (m_eventType != eventTypes.getQuit() && m_eventType != eventTypes.getPrint() && m_eventType != eventTypes.getServed() && m_eventType != eventTypes.getEnter())
    {
        throw std::invalid_argument("Event::getEventType(): The event type is corruted, since it doesn't correspond to any one of " + eventTypes.getQuit() + ", " + eventTypes.getPrint() + ", " + eventTypes.getServed() + " or " + eventTypes.getEnter() + ".");
    }
    else
    {
        return m_eventType;
    }
}

//  Purpose: The following method sets the object modeling a pupil of the parsed event.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: Schueler newSchueler
//  Throws: std::invalid_argument
void Event::setSchueler(Schueler newSchueler) throw(std::invalid_argument)
{
    m_Schueler = newSchueler;
}
