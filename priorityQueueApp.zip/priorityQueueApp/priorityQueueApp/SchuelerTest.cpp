//  SchuelerTest.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 16.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include "SchuelerTest.h"

//  Purpose: The following test covers the standard constructor as well as the happy path for the setters of the members m_id, m_name and m_cgpa.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testStandardConstructorAndCorrectlyUsedIdNameCgpaSetters() throw(std::runtime_error)
{
    Schueler schueler;
    bool isIdCorrect = (schueler.getId() == 9876);
    bool isNameCorrect = (schueler.getName() == "Charles");
    bool isCgpaCorrect = (schueler.getCgpa() == 3.21);
    if (isIdCorrect == false || isNameCorrect == false || isCgpaCorrect == false)
    {
        throw std::runtime_error("SchuelerTest::testStandardConstructorAndCorrectlyUsedIdNameCgpaSetters(): Test failed.");
    }
    else
    {
        std::cout << "SchuelerTest::testStandardConstructorAndCorrectlyUsedIdNameCgpaSetters(): Test passed.\n";
    }
}

//  Purpose: The following test covers the explicit constructor with an invalid identifier.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testExplicitConstructorAndWronglySetId() throw(std::runtime_error)
{
    try
    {
        Schueler schueler(-1, "Harvey", 1.00);
        throw std::runtime_error("SchuelerTest::testExplicitConstructorAndWronglySetId(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "SchuelerTest::testExplicitConstructorAndWronglySetId(): Test passed.\n";
    }
}

//  Purpose: The following test covers the explicit constructor with an invalid name.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testSetWrongName() throw(std::runtime_error)
{
    Schueler schueler(1, "Alan", 1.01);
    try
    {
        schueler.setName("alan");
        throw std::runtime_error("SchuelerTest::testSetWrongName(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "SchuelerTest::testSetWrongName(): Test passed.\n";
    }
}

//  Purpose: The following test covers the explicit constructor with an invalid CGPA.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testSetWrongCgpa() throw(std::runtime_error)
{
    Schueler schueler(2, "Steve", 1.02);
    try
    {
        schueler.setCgpa(9.99);
        throw std::runtime_error("SchuelerTest::testSetWrongCgpa(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "SchuelerTest::testSetWrongCgpa(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a regular identifier.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testGetId() throw(std::runtime_error)
{
    Schueler schueler(3, "Kimberly", 1.03);
    if (schueler.getId() != 3)
    {
        throw std::runtime_error("SchuelerTest::testGetId(): Test failed.");
    }
    else
    {
        std::cout << "SchuelerTest::testGetId(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a wrong identifier by provocating data corruption.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testGetWrongId() throw(std::runtime_error)
{
    Schueler schueler(4, "Jamie", 1.04);
    schueler.m_id = -1;
    try
    {
        schueler.getId();
        throw std::runtime_error("SchuelerTest::testGetWrongId(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "SchuelerTest::testGetWrongId(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a regular name.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testGetName() throw(std::runtime_error)
{
    Schueler schueler(5, "Susan", 1.05);
    if (schueler.getName() != "Susan")
    {
        throw std::runtime_error("SchuelerTest::testGetName(): Test failed.");
    }
    else
    {
        std::cout << "SchuelerTest::testGetName(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a wrong name by provocating data corruption.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testGetWrongName() throw(std::runtime_error)
{
    Schueler schueler(6, "Billy", 1.06);
    schueler.m_name = "biLLy";
    try
    {
        schueler.getName();
        throw std::runtime_error("SchuelerTest::testGetWrongName(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "SchuelerTest::testGetWrongName(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a regular name.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testGetCgpa() throw(std::runtime_error)
{
    Schueler schueler(7, "Allison", 1.07);
    if (schueler.getCgpa() != 1.07)
    {
        throw std::runtime_error("SchuelerTest::testGetCgpa(): Test failed.");
    }
    else
    {
        std::cout << "SchuelerTest::testGetCgpa(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a wrong CGPA by provocating data corruption.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testGetWrongCgpa() throw(std::runtime_error)
{
    Schueler schueler(8, "Dudley", 1.08);
    schueler.m_cgpa = 100001;
    try
    {
        schueler.getCgpa();
        throw std::runtime_error("SchuelerTest::testGetWrongCgpa(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "SchuelerTest::testGetWrongCgpa(): Test passed.\n";
    }
}

//  Purpose: The following test covers the conversion of the data of an object modelling a pupil into a string.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testConvertToString() throw(std::runtime_error)
{
    std::string megansExpectedData = "Pupil: Name = Megan, ID = 9, CGPA = 1.09.";
    Schueler schueler(9, "Megan", 1.09);
    try
    {
        std::string megansActualData = schueler.convertToString();
        if (megansActualData != megansExpectedData)
        {
            throw std::runtime_error("SchuelerTest::testConvertToString(): Test failed. The pupil's actual data (" + megansActualData + ") differs from the expected (" + megansExpectedData + ") one.");
        }
        else
        {
            std::cout << "SchuelerTest::testConvertToString(): Test passed.\n";
        }
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("SchuelerTest::testConvertToString(): Test failed. The pupil's data is not correct and can't be converted into a string.");
    }
}

//  Purpose: The following test covers the comparison of two identical objects modelling pupils.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testEqualsToIdentity() throw(std::runtime_error)
{
    Schueler schuelerRick(26, "Rick", 1.26);
    Schueler schuelerAnotherRick(26, "Rick", 1.26);
    if (schuelerRick.equalsTo(schuelerAnotherRick))
    {
        std::cout << "SchuelerTest::testEqualsToIdentity(): Test passed.\n";
    }
    else
    {
        throw std::runtime_error("SchuelerTest::testEqualsToIdentity(): Test failed.");
    }
}

//  Purpose: The following test covers the comparison of two different objects modelling pupils.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void SchuelerTest::testEqualsToDiversity() throw(std::runtime_error)
{
    Schueler schuelerRick(26, "Rick", 1.26);
    Schueler schuelerLucille(27, "Lucille", 1.27);
    if (schuelerRick.equalsTo(schuelerLucille))
    {
        throw std::runtime_error("SchuelerTest::testEqualsToDiversity(): Test failed.");
    }
    else
    {
        std::cout << "SchuelerTest::testEqualsToDiversity(): Test passed.\n";
    }
}

//  Purpose: The following test aggregates all tests of this class.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void SchuelerTest::runAllTests() throw(std::runtime_error)
{
    testStandardConstructorAndCorrectlyUsedIdNameCgpaSetters();
    testExplicitConstructorAndWronglySetId();
    testSetWrongName();
    testSetWrongCgpa();
    testGetId();
    testGetWrongId();
    testGetName();
    testGetWrongName();
    testGetCgpa();
    testGetWrongCgpa();
    testConvertToString();
    testEqualsToIdentity();
    testEqualsToDiversity();
    std::cout << "SchuelerTest::runAllTests(): All tests ran sucessfully.\n";
}
