//  EventTypes.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include "EventTypes.h"

//  Purpose: The following method constructs an instance of this class.
//  Reason: Centralization of the keywords, representing the event identifiers.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Throws: std::invalid_argument
EventTypes::EventTypes() throw(std::invalid_argument)
{
    setEnter("ENTER");
    setQuit("QUIT");
    setServed("SERVED");
    setPrint("PRINT");
}

//  Purpose: The following method returns the identifier to enter a new entry for a pupil.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Returns: std::string event identifier
//  Throws: std::invalid_argument
std::string EventTypes::getEnter() throw(std::invalid_argument)
{
    if (m_enterNewPupilEntry.empty() == true)
    {
        throw std::invalid_argument("EventTypes::getEnter(): The current event value is corrupted.");
    }
    else
    {
        return m_enterNewPupilEntry;
    }
}

//  Purpose: The following method sets the identifier to enter a new entry for a pupil.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::list<std::string> event identifier
//  Throws: std::invalid_argument
void EventTypes::setEnter(std::string newEnterEvent) throw(std::invalid_argument)
{
    if (newEnterEvent.empty() == true)
    {
        throw std::invalid_argument("EventTypes::setEnter(std::string newEnterEvent == ''): The given event must any alphanumeric content.");
    }
    else
    {
        m_enterNewPupilEntry = newEnterEvent;
    }
}

//  Purpose: The following method returns the identifier to quit this application.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Returns: std::string event identifier
//  Throws: std::invalid_argument
std::string EventTypes::getQuit() throw(std::invalid_argument)
{
    if (m_quitApplication.empty() == true)
    {
        throw std::invalid_argument("EventTypes::getQuit(): The current event value is corrupted.");
    }
    else
    {
        return m_quitApplication;
    }
}

//  Purpose: The following method sets the identifier to quit this application.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::list<std::string> event identifier
//  Throws: std::invalid_argument
void EventTypes::setQuit(std::string newQuitEvent) throw(std::invalid_argument)
{
    if (newQuitEvent.empty() == true)
    {
        throw std::invalid_argument("EventTypes::setQuit(std::string newQuitEvent == ''): The given event must any alphanumeric content.");
    }
    else
    {
        m_quitApplication = newQuitEvent;
    }
}

//  Purpose: The following method returns the identifier to mark a pupil being served and popped out of the priority list.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Returns: std::string event identifier
//  Throws: std::invalid_argument
std::string EventTypes::getServed() throw(std::invalid_argument)
{
    if (m_highestPrioritizedServed.empty() == true)
    {
        throw std::invalid_argument("EventTypes::getServed(): The current event value is corrupted.");
    }
    else
    {
        return m_highestPrioritizedServed;
    }
}

//  Purpose: The following method sets the identifier to mark a pupil being served and popped out of the priority list.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::list<std::string> event identifier
//  Throws: std::invalid_argument
void EventTypes::setServed(std::string newServedEvent) throw(std::invalid_argument)
{
    if (newServedEvent.empty() == true)
    {
        throw std::invalid_argument("EventTypes::setServed(std::string newServedEvent == ''): The given event must any alphanumeric content.");
    }
    else
    {
        m_highestPrioritizedServed = newServedEvent;
    }
}

//  Purpose: The following method returns the identifier to print the priority list.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Returns: std::string event identifier
//  Throws: std::invalid_argument
std::string EventTypes::getPrint() throw(std::invalid_argument)
{
    if (m_printPendingPupilEntries.empty() == true)
    {
        throw std::invalid_argument("EventTypes::getPrint(): The current event value is corrupted.");
    }
    else
    {
        return m_printPendingPupilEntries;
    }
}

//  Purpose: The following method sets the identifier to print the priority list.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::list<std::string> event identifier
//  Throws: std::invalid_argument
void EventTypes::setPrint(std::string newPrintEvent) throw(std::invalid_argument)
{
    if (newPrintEvent.empty() == true)
    {
        throw std::invalid_argument("EventTypes::setPrint(std::string newPrintEvent == ''): The given event must any alphanumeric content.");
    }
    else
    {
        m_printPendingPupilEntries = newPrintEvent;
    }
}
