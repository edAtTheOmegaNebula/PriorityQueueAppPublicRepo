//  EventTypesTest.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 17.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include "EventTypesTest.h"

//  Purpose: The following test covers the standard constructor as well as the happy path for the setters of the members m_enterNewPupilEntry, m_quitApplication, m_highestPrioritizedServed and m_printPendingPupilEntries.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testStandardConstructorAndCorrectlyUsedEnterQuitServedPrintSetters() throw(std::runtime_error)
{
    try
    {
        EventTypes eventTypes;
        std::cout << "EventTypesTest::testStandardConstructorAndCorrectlyUsedEnterQuitServedPrintSetters(): Test passed.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("EventTypesTest::testStandardConstructorAndCorrectlyUsedEnterQuitServedPrintSetters(): Test failed.");
    }
}

//  Purpose: The following test covers the explicit constructor with an invalid string for the command ENTER.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testSetWrongEnter() throw(std::runtime_error)
{
    EventTypes eventTypes;
    try
    {
        eventTypes.setEnter("");
        throw std::runtime_error("EventTypesTest::testSetWrongEnter(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTypesTest::testSetWrongEnter(): Test passed.\n";
    }
}

//  Purpose: The following test covers the explicit constructor with an invalid string for the command QUIT.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testSetWrongQuit() throw(std::runtime_error)
{
    EventTypes eventTypes;
    try
    {
        eventTypes.setQuit("");
        throw std::runtime_error("EventTypesTest::testSetWrongQuit(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTypesTest::testSetWrongQuit(): Test passed.\n";
    }
}

//  Purpose: The following test covers the explicit constructor with an invalid string for the command SERVED.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testSetWrongServed() throw(std::runtime_error)
{
    EventTypes eventTypes;
    try
    {
        eventTypes.setServed("");
        throw std::runtime_error("EventTypesTest::testSetWrongServed(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTypesTest::testSetWrongServed(): Test passed.\n";
    }
}

//  Purpose: The following test covers the explicit constructor with an invalid string for the command PRINT.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testSetWrongPrint() throw(std::runtime_error)
{
    EventTypes eventTypes;
    try
    {
        eventTypes.setPrint("");
        throw std::runtime_error("EventTypesTest::testSetWrongPrint(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTypesTest::testSetWrongPrint(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a string for the regular command ENTER.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testGetEnter() throw(std::runtime_error)
{
    EventTypes eventTypes;
    if (eventTypes.getEnter() != "ENTER")
    {
        throw std::runtime_error("EventTypesTest::testGetEnter(): Test failed.");
    }
    else
    {
        std::cout << "EventTypesTest::testGetEnter(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a wrong string for the regular command ENTER by provocating data corruption.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testGetWrongEnter() throw(std::runtime_error)
{
    EventTypes eventTypes;
    eventTypes.m_enterNewPupilEntry = "";
    try
    {
        eventTypes.getEnter();
        throw std::runtime_error("EventTypesTest::testGetWrongEnter(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTypesTest::testGetWrongEnter(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a string for the regular command QUIT.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testGetQuit() throw(std::runtime_error)
{
    EventTypes eventTypes;
    if (eventTypes.getQuit() != "QUIT")
    {
        throw std::runtime_error("EventTypesTest::testGetQuit(): Test failed.");
    }
    else
    {
        std::cout << "EventTypesTest::testGetQuit(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a wrong string for the regular command QUIT by provocating data corruption.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testGetWrongQuit() throw(std::runtime_error)
{
    EventTypes eventTypes;
    eventTypes.m_quitApplication = "";
    try
    {
        eventTypes.getQuit();
        throw std::runtime_error("EventTypesTest::testGetWrongQuit(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTypesTest::testGetWrongQuit(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a string for the regular command SERVED.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testGetServed() throw(std::runtime_error)
{
    EventTypes eventTypes;
    if (eventTypes.getServed() != "SERVED")
    {
        throw std::runtime_error("EventTypesTest::testGetServed(): Test failed.");
    }
    else
    {
        std::cout << "EventTypesTest::testGetServed(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a wrong string for the regular command SERVED by provocating data corruption.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testGetWrongServed() throw(std::runtime_error)
{
    EventTypes eventTypes;
    eventTypes.m_highestPrioritizedServed = "";
    try
    {
        eventTypes.getServed();
        throw std::runtime_error("EventTypesTest::testGetWrongServed(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTypesTest::testGetWrongServed(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a string for the regular command PRINT.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testGetPrint() throw(std::runtime_error)
{
    EventTypes eventTypes;
    if (eventTypes.getPrint() != "PRINT")
    {
        throw std::runtime_error("EventTypesTest::testGetPrint(): Test failed.");
    }
    else
    {
        std::cout << "EventTypesTest::testGetPrint(): Test passed.\n";
    }
}

//  Purpose: The following test covers the standard constructor as well as obtaining a wrong string for the regular command PRINT by provocating data corruption.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTypesTest::testGetWrongPrint() throw(std::runtime_error)
{
    EventTypes eventTypes;
    eventTypes.m_printPendingPupilEntries = "";
    try
    {
        eventTypes.getPrint();
        throw std::runtime_error("EventTypesTest::testGetWrongPrint(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTypesTest::testGetWrongPrint(): Test passed.\n";
    }
}

//  Purpose: The following test aggregates all tests of this class.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::runtime_error
void EventTypesTest::runAllTests() throw(std::runtime_error)
{
    testStandardConstructorAndCorrectlyUsedEnterQuitServedPrintSetters();
    testSetWrongEnter();
    testSetWrongQuit();
    testSetWrongServed();
    testSetWrongPrint();
    testGetEnter();
    testGetWrongEnter();
    testGetQuit();
    testGetWrongQuit();
    testGetServed();
    testGetWrongServed();
    testGetPrint();
    testGetWrongPrint();
    std::cout << "EventTypesTest::runAllTests(): All tests ran sucessfully.\n";
}
