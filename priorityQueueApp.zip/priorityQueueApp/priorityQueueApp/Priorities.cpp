//  Priorities.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 15.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include "Priorities.h"

Priorities::Priorities()
{
    setIsListSortedByCgpa(false);
    setIsListSortedByNames(false);
    setIsListSortedByIdentifier(false);
}

//  Purpose: The following method processes the given list of events and returns the list of pupils to the first occurrence of the event "QUIT". The occurrence of the event "QUIT" introduces the shutdown of this application.
//  Reason: The customer demanded exactly this architecture.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::list<std::string> events
//  Returns: std::list<Schueler>
//  Throws: std::invalid_argument
std::list<Schueler> Priorities::getSchuelers(std::list<std::string> events) throw(std::invalid_argument)
{
    if (events.empty() == true)
    {
        throw std::invalid_argument("Priorities::getSchuelers(std::list<std::string> events): The given list of events has to contain any valid entries.");
    }
    else
    {
        while (events.empty() == false)
        {
            EventTypes eventTypes;
            std::string nextEvent = events.front();
            Event parsedEvent = parseEvent(nextEvent);
            events.pop_front();
            if (parsedEvent.getEventType() == eventTypes.getQuit())
            {
                std::cout << "Priorities::getSchuelers(std::list<std::string> events): QUIT-event detected. This application is halted immediately.\n";
                exit(0);
            }
            else if (parsedEvent.getEventType() == eventTypes.getPrint())
            {
                printSchuelerList(getSchuelerList());
            }
            else if (parsedEvent.getEventType() == eventTypes.getServed() && getSchuelerList().empty() == true)
            {
                std::cout << "Priorities::getSchuelers(std::list<std::string> events): Currently, there are no pupils registered in the list to be popped out.\n";
                continue;
            }
            else if (parsedEvent.getEventType() == eventTypes.getServed() && getSchuelerList().empty() == false)
            {
                if (getSchuelerList().size() == 1)
                {
                    eraseSchuelerList();
                }
                else
                {
                    std::list<Schueler> choppedList = getSchuelerList();
                    choppedList.pop_front();
                    setSchuelerList(choppedList);
                }
            }
            else if (parsedEvent.getEventType() == eventTypes.getEnter() && getSchuelerList().empty() == true)
            {
                std::list<Schueler> extendedList = getSchuelerList();
                extendedList.push_back(parsedEvent.getSchueler());
                setSchuelerList(extendedList);
            }
            else if (parsedEvent.getEventType() == eventTypes.getEnter() && getSchuelerList().empty() == false)
            {
                std::list<Schueler> extendedList = getSchuelerList();
                extendedList.push_back(parsedEvent.getSchueler());
                setSchuelerList(extendedList);
                sortByPriorities();
            }
            else
            {
                throw std::invalid_argument("Priorities::getSchuelers(std::list<std::string> events): Although the next event seems to be formatted correctly, the command doesn't correspont to any one of " + eventTypes.getEnter() + ", " + eventTypes.getPrint() + ", " + eventTypes.getServed() + " or " + eventTypes.getQuit() + ".");
            }
        }
        return getSchuelerList();
    }
}

//  Purpose: The following method returns the currently persisted list of pupils.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::list<std::string> events
//  Returns: std::list<Schueler>
//  Throws: std::invalid_argument
std::list<Schueler> Priorities::getSchuelerList()
{
    return m_schuelerList;
}

//  Purpose: The following method repaces the currently persisted list of pupils by the given one, unless it is not empty.
//  Reason: Centralization of business-logic for the access of this member.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::list<Schueler> newSchuelerList
//  Throws: std::invalid_argument
void Priorities::setSchuelerList(std::list<Schueler> newSchuelerList) throw(std::invalid_argument)
{
    if (newSchuelerList.empty() == true)
    {
        throw std::invalid_argument("Priorities::setSchuelerList(std::list<Schueler> newSchuelerList): The given list has to contain any entries. In order to erase the list, please use the method eraseSchuelerList.");
    }
    else
    {
        m_schuelerList = newSchuelerList;
    }
}

//  Purpose: The following method returns the current value of m_isListSortedByCgpa.
//  Reason: Clean-Code access to members.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Returns: bool isListSortedByCgpa
bool Priorities::getIsListSortedByCgpa()
{
    return m_isListSortedByCgpa;
}

//  Purpose: The following method sets a new value for m_isListSortedByCgpa.
//  Reason: Clean-Code access to members.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Parameters: bool newIsListSortedByCgpa
void Priorities::setIsListSortedByCgpa(bool newIsListSortedByCgpa)
{
    m_isListSortedByCgpa = newIsListSortedByCgpa;
}

//  Purpose: The following method returns the current value of m_isListSortedByNames.
//  Reason: Clean-Code access to members.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Returns: bool isListSortedByNames
bool Priorities::getIsListSortedByNames()
{
    return m_isListSortedByNames;
}

//  Purpose: The following method sets a new value for m_isListSortedByNames.
//  Reason: Clean-Code access to members.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Parameters: bool newIsListSortedByNames
void Priorities::setIsListSortedByNames(bool newIsListSortedByNames)
{
    m_isListSortedByNames = newIsListSortedByNames;
}

//  Purpose: The following method returns the current value of m_isListSortedByIdentifier.
//  Reason: Clean-Code access to members.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Returns: bool isListSortedByIdentifier
bool Priorities::getIsListSortedByIdentifier()
{
    return m_isListSortedByIdentifier;
}

//  Purpose: The following method sets a new value for m_isListSortedByIdentifier.
//  Reason: Clean-Code access to members.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Parameters: bool newIsListSortedByIdentifier
void Priorities::setIsListSortedByIdentifier(bool newIsListSortedByIdentifier)
{
    m_isListSortedByIdentifier = newIsListSortedByIdentifier;
}

//  Purpose: The following method parses a given event into an Event-object.
//  Reason: Differentiation of the specified events.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::string event
//  Returns: Event event
//  Throws: std::invalid_argument
Event Priorities::parseEvent(std::string event) throw(std::invalid_argument)
{
    if (event.empty() == true)
    {
        throw std::invalid_argument("Priorities::parseEvent(std::string event == ''): The given event must contain a proper content.");
    }
    else
    {
        bool isCorrectlyFormatted = std::regex_match(event, std::regex("^(ENTER|SERVED|PRINT|QUIT){1}( ([A-Za-z]{2,}){1,} [0-9]{1}.[0-9]{2} [0-9]{1,5}){0,1}$"));
        if (isCorrectlyFormatted == true)
        {
            EventTypes eventTypes;
            std::istringstream iStringStream(event);
            std::vector<std::string> eventChunks(std::istream_iterator<std::string>{iStringStream}, std::istream_iterator<std::string>());
            if (eventChunks.at(0) == eventTypes.getQuit())
            {
                Event event(eventTypes.getQuit());
                return event;
            }
            else if(eventChunks.at(0) == eventTypes.getServed())
            {
                Event event(eventTypes.getServed());
                return event;
            }
            else if(eventChunks.at(0) == eventTypes.getPrint())
            {
                Event event(eventTypes.getPrint());
                return event;
            }
            else if(eventChunks.at(0) == eventTypes.getEnter())
            {
                
                Schueler schueler(std::stoi(eventChunks.at(3)), eventChunks.at(1), std::stod(eventChunks.at(2)));
                Event event(eventTypes.getEnter(), schueler);
                return event;
            }
            else
            {
                throw std::invalid_argument("Priorities::parseEvent(std::string event == " + event + "): Although the event seems to be formatted correctly, the command doesn't correspont to any one of " + eventTypes.getEnter() + ", " + eventTypes.getPrint() + ", " + eventTypes.getServed() + " or " + eventTypes.getQuit() + ".");
            }
        }
        else
        {
            throw std::invalid_argument("Priorities::parseEvent(std::string event == " + event + "): The given event must be correctly formatted: <ENTER|SERVED|PRINT|QUIT> <The pupil's name> <CGPA> <Identifier>");
        }
    }
}

//  Purpose: The following method erases the currently persisted list of pupils.
//  Reason: Completion of CRUD-Operations for the list of pupils.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
void Priorities::eraseSchuelerList()
{
    if (m_schuelerList.empty() == true)
    {
        std::cout << "void Priorities::eraseSchuelerList(): The list of pupils is already empty.\n";
    }
    else
    {
        m_schuelerList.erase(m_schuelerList.begin(), m_schuelerList.end());
    }
}

//  Purpose: The following method prints the list of objects modeling pupils.
//  Reason: Differentiation of the specified events.
//  Author: Edhem Bajrić
//  Date: 15.05.2020
//  Parameters: std::string event
//  Returns: Event event
//  Throws: std::invalid_argument
void Priorities::printSchuelerList(std::list<Schueler> schuelerListToPrint)
{
    if (schuelerListToPrint.empty() == true)
    {
        std::cout << "void Priorities::printSchuelerList(std::list<Schueler> schuelerListToPrint): The given list is empty. LEER.\n";
    }
    else
    {
        for(int i = 0; i < schuelerListToPrint.size(); i++)
        {
            std::list<Schueler>::iterator iThSchueler = schuelerListToPrint.begin();
            std::advance(iThSchueler, i);
            std::cout << (*iThSchueler).convertToString() << "\n";
        }
    }
}

//  Purpose: The following method sorts a given list of pupils by their CGPA only.
//  Reason: Separation of concerns. Ascending CGPAs refer to the corresponding mathematical relation between CGPAs of two neighboured objects. A vector is used for an easier swapping of the list's elements.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::invalid_argument
void Priorities::sortByCgpa() throw(std::invalid_argument)
{
    if (getIsListSortedByCgpa() == true || getIsListSortedByNames() == true || getIsListSortedByIdentifier() == true)
    {
        throw std::invalid_argument("Priorities::sortByCgpa(): This method has exclusively to be called, if a given list of pupils is not sorted by one of the methods sortByCgpa(), sortByNames() or sortByIdentifiers() before.");
    }
    else if (getSchuelerList().empty())
    {
        throw std::invalid_argument("Priorities::sortByCgpa(): Sorting the list of pupils cannot be performed, since it has no content.");
    }
    else if (getSchuelerList().size() == 1)
    {
        std::cout << "Priorities::sortByCgpa(): The list of pupils remains the same, since it has just one entry.\n";
        setIsListSortedByCgpa(true);
    }
    else
    {
        long elementsToIterate = getSchuelerList().size() - 1;
        std::list<Schueler> copyOfSchuelerList = getSchuelerList();
        std::vector<Schueler> schuelerVector(copyOfSchuelerList.size());
        std::copy(copyOfSchuelerList.begin(), copyOfSchuelerList.end(), schuelerVector.begin());
        while (elementsToIterate >= 1)
        {
            for (int i = 0; i < elementsToIterate; i++)
            {
                bool areCgpasAscending = (schuelerVector.at(i).getCgpa() < schuelerVector.at(i + 1).getCgpa());
                if (areCgpasAscending == true)
                {
                    Schueler backuppedIthSchueler(schuelerVector.at(i));
                    schuelerVector.at(i) = schuelerVector.at(i + 1);
                    schuelerVector.at(i + 1) = backuppedIthSchueler;
                }
                else
                {
                    continue;
                }
            }
            elementsToIterate--;
        }
        std::list<Schueler> cgpaSortedSchuelerList;
        std::copy(schuelerVector.begin(), schuelerVector.end(), std::back_inserter(cgpaSortedSchuelerList));
        setSchuelerList(cgpaSortedSchuelerList);
        setIsListSortedByCgpa(true);
    }
}

//  Purpose: The following method sorts a given list of pupils by their names exclusively right after the meant list was sorted by CGPA. Therefore, a previously CGPA-sorted list must be passed.
//  Reason: Separation of concerns. Descending names refer to the corresponding alphabetical relation between names of two neighboured objects. A vector is used for an easier swapping of the list's elements.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::invalid_argument
void Priorities::sortByNames() throw(std::invalid_argument)
{
    if (getIsListSortedByCgpa() == false || getIsListSortedByNames() == true || getIsListSortedByIdentifier() == true)
    {
        throw std::invalid_argument("Priorities::sortByNames(): This method has exclusively to be called right after sorting a given list of pupils by the method sortByCgpa().");
    }
    else if (getSchuelerList().empty())
    {
        throw std::invalid_argument("Priorities::sortByNames(): Sorting the list of pupils cannot be performed, since it has no content. The sorting process seems to be corrupted.");
    }
    else if (getSchuelerList().size() == 1)
    {
        std::cout << "Priorities::sortByNames(): The list of pupils remains the same, since it has just one entry.\n";
        setIsListSortedByNames(true);
    }
    else
    {
        long elementsToIterate = getSchuelerList().size() - 1;
        std::list<Schueler> copyOfSchuelerList = getSchuelerList();
        std::vector<Schueler> schuelerVector(copyOfSchuelerList.size());
        std::copy(copyOfSchuelerList.begin(), copyOfSchuelerList.end(), schuelerVector.begin());
        while (elementsToIterate >= 1)
        {
            for (int i = 0; i < elementsToIterate; i++)
            {
                bool areCgpasIdentical = (schuelerVector.at(i).getCgpa() == schuelerVector.at(i + 1).getCgpa());
                bool areNamesDescending = (schuelerVector.at(i).getName() > schuelerVector.at(i + 1).getName());
                if (areCgpasIdentical == true && areNamesDescending == true)
                {
                    Schueler backuppedIthSchueler(schuelerVector.at(i));
                    schuelerVector.at(i) = schuelerVector.at(i + 1);
                    schuelerVector.at(i + 1) = backuppedIthSchueler;
                }
                else
                {
                    continue;
                }
            }
            elementsToIterate--;
        }
        std::list<Schueler> cgpaNameSortedSchuelerList;
        std::copy(schuelerVector.begin(), schuelerVector.end(), std::back_inserter(cgpaNameSortedSchuelerList));
        setSchuelerList(cgpaNameSortedSchuelerList);
        setIsListSortedByNames(true);
    }
}

//  Purpose: The following method sorts a given list of pupils by their identifiers exclusively right after the meant list was sorted by consecutively both, CGPA and names. Therefore, a previously both, CGPA-sorted and name-sorted list must be passed.
//  Reason: Separation of concerns. Descending identifiers refer to the corresponding mathematical relation between identifiers of two neighboured objects. A vector is used for an easier swapping of the list's elements.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::invalid_argument
void Priorities::sortByIdentifiers() throw(std::invalid_argument)
{
    if (getIsListSortedByCgpa() == false || getIsListSortedByNames() == false || getIsListSortedByIdentifier() == true)
    {
        throw std::invalid_argument("Priorities::sortByIdentifiers(): This method has exclusively to be called right after sorting a given list of pupils consecutively by both methods, sortByCgpa() and sortByNames().");
    }
    else if (getSchuelerList().empty())
    {
        throw std::invalid_argument("Priorities::sortByIdentifiers(): Sorting the list of pupils cannot be performed, since it has no content. The sorting process seems to be corrupted.");
    }
    else if (getSchuelerList().size() == 1)
    {
        std::cout << "Priorities::sortByIdentifiers(): The list of pupils remains the same, since it has just one entry.\n";
        setIsListSortedByIdentifier(true);
    }
    else
    {
        long elementsToIterate = getSchuelerList().size() - 1;
        std::list<Schueler> copyOfSchuelerList = getSchuelerList();
        std::vector<Schueler> schuelerVector(copyOfSchuelerList.size());
        std::copy(copyOfSchuelerList.begin(), copyOfSchuelerList.end(), schuelerVector.begin());
        while (elementsToIterate >= 1)
        {
            for (int i = 0; i < elementsToIterate; i++)
            {
                bool areCgpasIdentical = (schuelerVector.at(i).getCgpa() == schuelerVector.at(i + 1).getCgpa());
                bool areNamesIdentical = (schuelerVector.at(i).getName() == schuelerVector.at(i + 1).getName());
                bool areIdentifiersDescending = (schuelerVector.at(i).getId() > schuelerVector.at(i + 1).getId());
                if (areCgpasIdentical == true && areNamesIdentical == true && areIdentifiersDescending == true)
                {
                    Schueler backuppedIthSchueler(schuelerVector.at(i));
                    schuelerVector.at(i) = schuelerVector.at(i + 1);
                    schuelerVector.at(i + 1) = backuppedIthSchueler;
                }
                else
                {
                    continue;
                }
            }
            elementsToIterate--;
        }
        std::list<Schueler> prioritySortedSchuelerList;
        std::copy(schuelerVector.begin(), schuelerVector.end(), std::back_inserter(prioritySortedSchuelerList));
        setSchuelerList(prioritySortedSchuelerList);
        setIsListSortedByIdentifier(true);
    }
}

//  Purpose: The following method sorts a given list of pupils consecutively by their CGPAs, names and identifiers. Therefore, the passed list mustn't be sorted by any of the methods sortByCgpa(), sortByNames() or sortByIdentifiers().
//  Reason: Separation of concerns. Descending identifiers refer to the corresponding mathematical relation between identifiers of two neighboured objects. After finishing to sort a list of pupils by priorities, the corresponding flags do have to be set back to false in order to enable to sort the list again after the next pupil registered to the list.
//  Author: Edhem Bajrić
//  Date: 16.05.2020
//  Throws: std::invalid_argument
void Priorities::sortByPriorities() throw(std::invalid_argument)
{
    if (getIsListSortedByCgpa() == true || getIsListSortedByNames() == true || getIsListSortedByIdentifier() == true)
    {
        throw std::invalid_argument("Priorities::sortByPriorities(): This method has exclusively to be called, if a given list of pupils is not sorted by one of the methods sortByCgpa(), sortByNames() or sortByIdentifiers() before.");
    }
    else if (getSchuelerList().empty())
    {
        throw std::invalid_argument("Priorities::sortByPriorities(): Sorting the list of pupils cannot be performed, since it has no content.");
    }
    else if (getSchuelerList().size() == 1)
    {
        std::cout << "Priorities::sortByCgpa(): The list of pupils remains the same, since it has just one entry.\n";
        setIsListSortedByCgpa(false);
        setIsListSortedByNames(false);
        setIsListSortedByIdentifier(false);
    }
    else
    {
        sortByCgpa();
        sortByNames();
        sortByIdentifiers();
        setIsListSortedByCgpa(false);
        setIsListSortedByNames(false);
        setIsListSortedByIdentifier(false);
    }
}
