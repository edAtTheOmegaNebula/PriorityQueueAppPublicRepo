//  EventTest.cpp
//  priorityQueueApp
//
//  Created by Edhem Bajric on 17.05.20.
//  Copyright © 2020 Edhem Bajrić. All rights reserved.

#include "EventTest.h"

//  Purpose: The following test covers the constructor for the event QUIT as well as the happy path for the setter of the member m_eventType.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTest::testConstructorForQuitEventsAndCorrectlyUsedEventTypeSetter() throw(std::runtime_error)
{
    EventTypes eventTypes;
    try
    {
        Event event(eventTypes.getQuit());
        std::cout << "EventTest::testConstructorForQuitEventsAndCorrectlyUsedEventTypeSetter(): Test passed.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("EventTest::testConstructorForQuitEventsAndCorrectlyUsedEventTypeSetter(): Test failed.");
    }
}

//  Purpose: The following test covers the constructor for the event PRINT as well as the happy path for the setter of the member m_eventType.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTest::testConstructorForPrintEventsAndCorrectlyUsedEventTypeSetter() throw(std::runtime_error)
{
    EventTypes eventTypes;
    try
    {
        Event event(eventTypes.getPrint());
        std::cout << "EventTest::testConstructorForPrintEventsAndCorrectlyUsedEventTypeSetter(): Test passed.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("EventTest::testConstructorForPrintEventsAndCorrectlyUsedEventTypeSetter(): Test failed.");
    }
}

//  Purpose: The following test covers the constructor for the event SERVED as well as the happy path for the setter of the member m_eventType.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTest::testConstructorForServedEventsAndCorrectlyUsedEventTypeSetter() throw(std::runtime_error)
{
    EventTypes eventTypes;
    try
    {
        Event event(eventTypes.getServed());
        std::cout << "EventTest::testConstructorForServedEventsAndCorrectlyUsedEventTypeSetter(): Test passed.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("EventTest::testConstructorForServedEventsAndCorrectlyUsedEventTypeSetter(): Test failed.");
    }
}

//  Purpose: The following test covers the constructor for the event ENTER as well as the happy path for the setters of the members m_eventType and m_Schueler.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTest::testExplicitConstructorForEnterEventAndCorrectlyUsedEventTypeSchuelerSetters() throw(std::runtime_error)
{
    EventTypes eventTypes;
    Schueler schueler(10, "Riley", 1.10);
    try
    {
        Event event(eventTypes.getEnter(), schueler);
        std::cout << "EventTest::testExplicitConstructorForEnterEventAndCorrectlyUsedEventTypeSchuelerSetters(): Test passed.\n";
    }
    catch(const std::invalid_argument& e)
    {
        throw std::runtime_error("EventTest::testExplicitConstructorForEnterEventAndCorrectlyUsedEventTypeSchuelerSetters(): Test failed.");
    }
}

//  Purpose: The following test covers the constructor for the object event with a wrong event type. Since setting the event type is centralized in the appropriate setter, this test covers the execution of both constructors.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTest::testSetWrongEventType() throw(std::runtime_error)
{
    try
    {
        Event event("Gimme a giant size triple-cheese-peperoni-pizza.");
        throw std::runtime_error("EventTest::testSetWrongEventType(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTest::testSetWrongEventType(): Test passed.\n";
    }
}

//  Purpose: The following test covers the constructor for one of the events SERVED, PRINT or QUIT as well as obtaining a regular event type.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTest::testGetEventType() throw(std::runtime_error)
{
    EventTypes eventTypes;
    Event event(eventTypes.getServed());
    if (event.getEventType() != eventTypes.getServed())
    {
        throw std::runtime_error("EventTest::testGetEventType(): Test failed.");
    }
    else
    {
        std::cout << "EventTest::testGetEventType(): Test passed.\n";
    }
}

void EventTest::testGetWrongEventType() throw(std::runtime_error)
{
    EventTypes eventTypes;
    Event event(eventTypes.getServed());
    event.m_eventType = "";
    try
    {
        event.getEventType();
        throw std::runtime_error("EventTest::testGetWrongEventType(): Test failed.");
    }
    catch(const std::invalid_argument& e)
    {
        std::cout << "EventTest::testGetWrongEventType(): Test passed.\n";
    }
}

//  Purpose: The following test covers the constructor for the event ENTER as well as obtaining a regular object modelling a pupil.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTest::testGetSchueler() throw(std::runtime_error)
{
    EventTypes eventTypes;
    Schueler expectedSchueler(10, "Riley", 1.10);
    Event event(eventTypes.getEnter(), expectedSchueler);
    Schueler actualSchueler = event.getSchueler();
    bool doCgpasDiffer = (actualSchueler.getCgpa() != expectedSchueler.getCgpa());
    bool doNamesDiffer = (actualSchueler.getName() != expectedSchueler.getName());
    bool doIdsDiffer = (actualSchueler.getId() != expectedSchueler.getId());
    if (doCgpasDiffer == true || doNamesDiffer == true || doIdsDiffer == true)
    {
        throw std::runtime_error("EventTest::testGetSchueler(): Test failed.");
    }
    else
    {
        std::cout << "EventTest::testGetSchueler(): Test passed.\n";
    }
}

//  Purpose: The following test aggregates all tests of this class.
//  Author: Edhem Bajrić
//  Date: 17.05.2020
//  Throws: std::runtime_error
void EventTest::runAllTests() throw(std::runtime_error)
{
    testConstructorForQuitEventsAndCorrectlyUsedEventTypeSetter();
    testConstructorForPrintEventsAndCorrectlyUsedEventTypeSetter();
    testConstructorForServedEventsAndCorrectlyUsedEventTypeSetter();
    testExplicitConstructorForEnterEventAndCorrectlyUsedEventTypeSchuelerSetters();
    testSetWrongEventType();
    testGetEventType();
    testGetWrongEventType();
    testGetSchueler();
    std::cout << "EventTest::runAllTests(): All tests ran sucessfully.\n";
}
